/**
 * Sorting Algorithms - C++ OOP Implementation
 * Supports: bubble, insertion, selection, merge, quick sort
 * Outputs JSON steps for frontend visualization with highlighted comparisons/swaps
 */
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>
#include <algorithm>

class Sorter {
private:
    static std::string serializeArr(const std::vector<int>& arr,
                                     int cmp1 = -1, int cmp2 = -1,
                                     int sorted_upto = -1,
                                     int pivot = -1) {
        std::ostringstream oss;
        oss << "{\"arr\":[";
        for (size_t i = 0; i < arr.size(); i++) {
            if (i) oss << ",";
            oss << arr[i];
        }
        oss << "]";
        if (cmp1 >= 0) oss << ",\"cmp1\":" << cmp1;
        if (cmp2 >= 0) oss << ",\"cmp2\":" << cmp2;
        if (sorted_upto >= 0) oss << ",\"sortedUpto\":" << sorted_upto;
        if (pivot >= 0) oss << ",\"pivot\":" << pivot;
        oss << "}";
        return oss.str();
    }

    static void addStep(std::vector<std::string>& steps, const std::string& action,
                        const std::string& msg, const std::string& state,
                        int lineHint = -1) {
        std::ostringstream oss;
        oss << "{\"action\":\"" << action << "\","
            << "\"message\":\"" << msg << "\","
            << "\"state\":" << state;
        if (lineHint >= 0) oss << ",\"line\":" << lineHint;
        oss << "}";
        steps.push_back(oss.str());
    }

public:
    static void bubbleSort(std::vector<int> arr, std::vector<std::string>& steps) {
        int n = arr.size();
        addStep(steps, "start", "Starting Bubble Sort — adjacent swaps to bubble max to end",
                serializeArr(arr), 1);

        for (int i = 0; i < n - 1; i++) {
            bool swapped = false;
            for (int j = 0; j < n - i - 1; j++) {
                addStep(steps, "compare", "Comparing arr[" + std::to_string(j) + "]=" +
                    std::to_string(arr[j]) + " and arr[" + std::to_string(j+1) + "]=" + std::to_string(arr[j+1]),
                    serializeArr(arr, j, j+1, n-i), 4);

                if (arr[j] > arr[j + 1]) {
                    std::swap(arr[j], arr[j + 1]);
                    swapped = true;
                    addStep(steps, "swap", "Swapped " + std::to_string(arr[j+1]) + " ↔ " + std::to_string(arr[j]),
                            serializeArr(arr, j, j+1, n-i), 5);
                }
            }
            addStep(steps, "pass", "Pass " + std::to_string(i+1) + " done — " +
                std::to_string(arr[n-1-i]) + " is in position",
                serializeArr(arr, -1, -1, n-i-1), 7);
            if (!swapped) {
                addStep(steps, "earlyExit", "No swaps — array is sorted! Early exit.", serializeArr(arr, -1, -1, 0), 9);
                break;
            }
        }
        addStep(steps, "done", "Bubble Sort complete!", serializeArr(arr, -1, -1, 0));
    }

    static void insertionSort(std::vector<int> arr, std::vector<std::string>& steps) {
        int n = arr.size();
        addStep(steps, "start", "Starting Insertion Sort — build sorted portion one element at a time",
                serializeArr(arr, -1, -1, 0), 1);

        for (int i = 1; i < n; i++) {
            int key = arr[i], j = i - 1;
            addStep(steps, "pick", "Picked key = " + std::to_string(key) + " at index " + std::to_string(i),
                    serializeArr(arr, i, -1, i), 3);

            while (j >= 0 && arr[j] > key) {
                addStep(steps, "shift", "arr[" + std::to_string(j) + "]=" + std::to_string(arr[j]) +
                    " > key=" + std::to_string(key) + ", shifting right",
                    serializeArr(arr, j, j+1, i), 5);
                arr[j + 1] = arr[j];
                j--;
            }
            arr[j + 1] = key;
            addStep(steps, "insert", "Inserted " + std::to_string(key) + " at position " + std::to_string(j+1),
                    serializeArr(arr, -1, -1, i), 7);
        }
        addStep(steps, "done", "Insertion Sort complete!", serializeArr(arr, -1, -1, n-1));
    }

    static void selectionSort(std::vector<int> arr, std::vector<std::string>& steps) {
        int n = arr.size();
        addStep(steps, "start", "Starting Selection Sort — find minimum and place it at start",
                serializeArr(arr), 1);

        for (int i = 0; i < n - 1; i++) {
            int minIdx = i;
            addStep(steps, "findMin", "Looking for minimum in unsorted portion [" +
                std::to_string(i) + "..." + std::to_string(n-1) + "]",
                serializeArr(arr, i, -1, i), 3);

            for (int j = i + 1; j < n; j++) {
                addStep(steps, "compare", "Comparing arr[" + std::to_string(j) + "]=" +
                    std::to_string(arr[j]) + " with current min " + std::to_string(arr[minIdx]),
                    serializeArr(arr, j, minIdx, i), 4);
                if (arr[j] < arr[minIdx]) {
                    minIdx = j;
                    addStep(steps, "newMin", "New minimum found: " + std::to_string(arr[minIdx]) + " at index " + std::to_string(minIdx),
                            serializeArr(arr, minIdx, i, i), 5);
                }
            }
            if (minIdx != i) {
                std::swap(arr[i], arr[minIdx]);
                addStep(steps, "swap", "Swapped minimum " + std::to_string(arr[i]) + " to index " + std::to_string(i),
                        serializeArr(arr, i, minIdx, i), 7);
            }
            addStep(steps, "placed", "arr[" + std::to_string(i) + "]=" + std::to_string(arr[i]) + " is now in correct position",
                    serializeArr(arr, -1, -1, i), 8);
        }
        addStep(steps, "done", "Selection Sort complete!", serializeArr(arr, -1, -1, n-1));
    }

    static void merge(std::vector<int>& arr, int l, int m, int r,
                      std::vector<std::string>& steps) {
        std::vector<int> left(arr.begin()+l, arr.begin()+m+1);
        std::vector<int> right(arr.begin()+m+1, arr.begin()+r+1);
        int i = 0, j = 0, k = l;

        addStep(steps, "merge", "Merging [" + std::to_string(l) + ".." + std::to_string(m) +
            "] and [" + std::to_string(m+1) + ".." + std::to_string(r) + "]",
            serializeArr(arr, l, r), 10);

        while (i < (int)left.size() && j < (int)right.size()) {
            if (left[i] <= right[j]) { arr[k++] = left[i++]; }
            else { arr[k++] = right[j++]; }
            addStep(steps, "mergeStep", "Placing " + std::to_string(arr[k-1]) + " at position " + std::to_string(k-1),
                    serializeArr(arr, k-1, -1), 11);
        }
        while (i < (int)left.size()) { arr[k++] = left[i++]; }
        while (j < (int)right.size()) { arr[k++] = right[j++]; }
    }

    static void mergeSortHelper(std::vector<int>& arr, int l, int r,
                                 std::vector<std::string>& steps) {
        if (l >= r) return;
        int m = l + (r - l) / 2;
        addStep(steps, "split", "Splitting [" + std::to_string(l) + ".." + std::to_string(r) + "] at mid=" + std::to_string(m),
                serializeArr(arr, l, r), 7);
        mergeSortHelper(arr, l, m, steps);
        mergeSortHelper(arr, m+1, r, steps);
        merge(arr, l, m, r, steps);
    }

    static void mergeSort(std::vector<int> arr, std::vector<std::string>& steps) {
        addStep(steps, "start", "Starting Merge Sort — divide and conquer approach",
                serializeArr(arr), 1);
        mergeSortHelper(arr, 0, arr.size()-1, steps);
        addStep(steps, "done", "Merge Sort complete!", serializeArr(arr, -1, -1, 0));
    }

    static int partition(std::vector<int>& arr, int low, int high,
                          std::vector<std::string>& steps) {
        int pivot = arr[high];
        int i = low - 1;

        addStep(steps, "pivot", "Pivot = " + std::to_string(pivot) + " (index " + std::to_string(high) + ")",
                serializeArr(arr, -1, high, -1, high), 5);

        for (int j = low; j < high; j++) {
            addStep(steps, "compare", "Comparing arr[" + std::to_string(j) + "]=" +
                std::to_string(arr[j]) + " with pivot=" + std::to_string(pivot),
                serializeArr(arr, j, high, -1, high), 7);

            if (arr[j] <= pivot) {
                i++;
                std::swap(arr[i], arr[j]);
                addStep(steps, "swap", "arr[" + std::to_string(j) + "]≤pivot, swapped with arr[" + std::to_string(i) + "]",
                        serializeArr(arr, i, j, -1, high), 8);
            }
        }
        std::swap(arr[i+1], arr[high]);
        addStep(steps, "placePivot", "Placed pivot " + std::to_string(pivot) + " at position " + std::to_string(i+1),
                serializeArr(arr, -1, -1, -1, i+1), 10);
        return i + 1;
    }

    static void quickSortHelper(std::vector<int>& arr, int low, int high,
                                  std::vector<std::string>& steps) {
        if (low < high) {
            addStep(steps, "quickPartition", "Partitioning [" + std::to_string(low) + ".." + std::to_string(high) + "]",
                    serializeArr(arr, low, high), 4);
            int pi = partition(arr, low, high, steps);
            quickSortHelper(arr, low, pi - 1, steps);
            quickSortHelper(arr, pi + 1, high, steps);
        }
    }

    static void quickSort(std::vector<int> arr, std::vector<std::string>& steps) {
        addStep(steps, "start", "Starting Quick Sort — partitioning around pivot",
                serializeArr(arr), 1);
        quickSortHelper(arr, 0, arr.size()-1, steps);
        addStep(steps, "done", "Quick Sort complete!", serializeArr(arr, -1, -1, 0));
    }
};

int main(int argc, char* argv[]) {
    std::string inputFile = (argc > 1) ? argv[1] : "input.txt";
    std::string outputFile = (argc > 2) ? argv[2] : "output.txt";

    std::ifstream fin(inputFile);
    if (!fin.is_open()) { std::cerr << "Cannot open: " << inputFile; return 1; }

    std::string algo;
    fin >> algo;
    int n; fin >> n;
    std::vector<int> arr(n);
    for (int& x : arr) fin >> x;
    fin.close();

    std::vector<std::string> steps;

    if (algo == "bubble") Sorter::bubbleSort(arr, steps);
    else if (algo == "insertion") Sorter::insertionSort(arr, steps);
    else if (algo == "selection") Sorter::selectionSort(arr, steps);
    else if (algo == "merge") Sorter::mergeSort(arr, steps);
    else if (algo == "quick") Sorter::quickSort(arr, steps);
    else { std::cerr << "Unknown algorithm: " << algo; return 1; }

    std::ofstream fout(outputFile);
    fout << "[";
    for (size_t i = 0; i < steps.size(); i++) {
        if (i) fout << ",";
        fout << steps[i];
    }
    fout << "]";
    fout.close();
    return 0;
}
