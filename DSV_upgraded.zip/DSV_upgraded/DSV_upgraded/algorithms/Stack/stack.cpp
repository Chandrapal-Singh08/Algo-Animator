/**
 * Stack - C++ OOP Implementation
 * Supports: push, pop, peek, isEmpty, size
 * Outputs JSON steps for frontend visualization
 */
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>
#include <stdexcept>

class Stack {
private:
    std::vector<int> data;
    static const int MAX_SIZE = 100;

    // Emit a JSON step for visualization
    void emitStep(std::vector<std::string>& steps, const std::string& action,
                  int value = -1, const std::string& msg = "") const {
        std::ostringstream oss;
        oss << "{\"action\":\"" << action << "\",";
        if (value != -1) oss << "\"value\":" << value << ",";
        oss << "\"message\":\"" << msg << "\",";
        oss << "\"state\":[";
        for (size_t i = 0; i < data.size(); i++) {
            if (i) oss << ",";
            oss << data[i];
        }
        oss << "]}";
        steps.push_back(oss.str());
    }

public:
    bool push(int val, std::vector<std::string>& steps) {
        if ((int)data.size() >= MAX_SIZE) {
            emitStep(steps, "overflow", val, "Stack overflow! Cannot push " + std::to_string(val));
            return false;
        }
        data.push_back(val);
        emitStep(steps, "push", val, "Pushed " + std::to_string(val) + " onto the stack");
        return true;
    }

    bool pop(std::vector<std::string>& steps) {
        if (data.empty()) {
            emitStep(steps, "underflow", -1, "Stack underflow! Cannot pop from empty stack");
            return false;
        }
        int val = data.back();
        data.pop_back();
        emitStep(steps, "pop", val, "Popped " + std::to_string(val) + " from the stack");
        return true;
    }

    void peek(std::vector<std::string>& steps) const {
        if (data.empty()) {
            // const cast trick for const method emitting
            std::vector<std::string> tmp;
            const_cast<Stack*>(this)->emitStep(const_cast<std::vector<std::string>&>(steps),
                "empty", -1, "Stack is empty");
            return;
        }
        const_cast<Stack*>(this)->emitStep(const_cast<std::vector<std::string>&>(steps),
            "peek", data.back(), "Top element is " + std::to_string(data.back()));
    }

    void currentState(std::vector<std::string>& steps) {
        emitStep(steps, "state", -1, "Current stack state");
    }

    bool isEmpty() const { return data.empty(); }
    int size() const { return (int)data.size(); }
};

int main(int argc, char* argv[]) {
    std::string inputFile = (argc > 1) ? argv[1] : "input.txt";
    std::string outputFile = (argc > 2) ? argv[2] : "output.txt";

    std::ifstream fin(inputFile);
    if (!fin.is_open()) {
        std::cerr << "Cannot open input file: " << inputFile << std::endl;
        return 1;
    }

    Stack stack;
    std::vector<std::string> steps;
    std::string cmd;
    int val;

    while (fin >> cmd) {
        if (cmd == "push") {
            if (fin >> val) stack.push(val, steps);
        } else if (cmd == "pop") {
            stack.pop(steps);
        } else if (cmd == "peek") {
            stack.peek(steps);
        }
    }
    fin.close();

    // Output JSON array of steps
    std::ofstream fout(outputFile);
    fout << "[";
    for (size_t i = 0; i < steps.size(); i++) {
        if (i) fout << ",";
        fout << steps[i];
    }
    fout << "]";
    fout.close();
    return 0;
}
