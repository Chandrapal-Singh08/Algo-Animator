/**
 * Kruskal's MST - C++ OOP Implementation
 * Uses Union-Find with path compression and rank
 * Outputs JSON steps for frontend visualization
 */
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>
#include <algorithm>

struct Edge {
    int u, v, w;
    bool operator<(const Edge& other) const { return w < other.w; }
};

class UnionFind {
    std::vector<int> parent, rank_;
public:
    explicit UnionFind(int n) : parent(n), rank_(n, 0) {
        for (int i = 0; i < n; i++) parent[i] = i;
    }
    int find(int x) {
        if (parent[x] != x) parent[x] = find(parent[x]); // path compression
        return parent[x];
    }
    bool unite(int x, int y) {
        int px = find(x), py = find(y);
        if (px == py) return false;
        if (rank_[px] < rank_[py]) std::swap(px, py);
        parent[py] = px;
        if (rank_[px] == rank_[py]) rank_[px]++;
        return true;
    }
};

class KruskalMST {
private:
    int n;
    std::vector<Edge> edges;

    void emitStep(std::vector<std::string>& steps, const std::string& action,
                  const Edge& e, const std::string& msg,
                  const std::vector<Edge>& mstEdges) {
        std::ostringstream oss;
        oss << "{\"action\":\"" << action << "\","
            << "\"u\":" << e.u << ",\"v\":" << e.v << ",\"w\":" << e.w << ","
            << "\"message\":\"" << msg << "\","
            << "\"mstEdges\":[";
        for (size_t i = 0; i < mstEdges.size(); i++) {
            if (i) oss << ",";
            oss << "{\"u\":" << mstEdges[i].u << ",\"v\":" << mstEdges[i].v << ",\"w\":" << mstEdges[i].w << "}";
        }
        oss << "]}";
        steps.push_back(oss.str());
    }

public:
    KruskalMST(int n, const std::vector<Edge>& edges) : n(n), edges(edges) {}

    void run(std::vector<std::string>& steps) {
        std::sort(edges.begin(), edges.end());
        UnionFind uf(n);
        std::vector<Edge> mstEdges;
        int totalCost = 0;

        // Initial state
        std::ostringstream init;
        init << "{\"action\":\"init\",\"message\":\"Sorted " << edges.size()
             << " edges by weight. Starting Kruskal's MST.\","
             << "\"edges\":[";
        for (size_t i = 0; i < edges.size(); i++) {
            if (i) init << ",";
            init << "{\"u\":" << edges[i].u << ",\"v\":" << edges[i].v << ",\"w\":" << edges[i].w << "}";
        }
        init << "],\"mstEdges\":[]}";
        steps.push_back(init.str());

        for (const auto& e : edges) {
            emitStep(steps, "consider", e,
                "Considering edge " + std::to_string(e.u) + "-" + std::to_string(e.v) + " (w=" + std::to_string(e.w) + ")",
                mstEdges);

            if (uf.unite(e.u, e.v)) {
                mstEdges.push_back(e);
                totalCost += e.w;
                emitStep(steps, "addEdge", e,
                    "Added edge " + std::to_string(e.u) + "-" + std::to_string(e.v) + " (no cycle formed)",
                    mstEdges);
            } else {
                emitStep(steps, "skipEdge", e,
                    "Skipped edge " + std::to_string(e.u) + "-" + std::to_string(e.v) + " (would form cycle)",
                    mstEdges);
            }

            if ((int)mstEdges.size() == n - 1) break;
        }

        std::ostringstream done;
        done << "{\"action\":\"done\",\"message\":\"MST complete. Total cost = " << totalCost << "\","
             << "\"totalCost\":" << totalCost << ","
             << "\"mstEdges\":[";
        for (size_t i = 0; i < mstEdges.size(); i++) {
            if (i) done << ",";
            done << "{\"u\":" << mstEdges[i].u << ",\"v\":" << mstEdges[i].v << ",\"w\":" << mstEdges[i].w << "}";
        }
        done << "]}";
        steps.push_back(done.str());
    }
};

int main(int argc, char* argv[]) {
    std::string inputFile = (argc > 1) ? argv[1] : "input.txt";
    std::string outputFile = (argc > 2) ? argv[2] : "output.txt";

    std::ifstream fin(inputFile);
    if (!fin.is_open()) { std::cerr << "Cannot open: " << inputFile; return 1; }

    int n, e; fin >> n >> e;
    std::vector<Edge> edges(e);
    for (int i = 0; i < e; i++) fin >> edges[i].u >> edges[i].v >> edges[i].w;
    fin.close();

    KruskalMST kruskal(n, edges);
    std::vector<std::string> steps;
    kruskal.run(steps);

    std::ofstream fout(outputFile);
    fout << "[";
    for (size_t i = 0; i < steps.size(); i++) {
        if (i) fout << ",";
        fout << steps[i];
    }
    fout << "]";
    fout.close();
    return 0;
}
