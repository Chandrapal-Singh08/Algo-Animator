/**
 * Dijkstra's Shortest Path - C++ OOP Implementation
 * Uses adjacency matrix input
 * Outputs JSON steps for frontend visualization
 */
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>
#include <climits>
#include <algorithm>

class Dijkstra {
private:
    int n;
    std::vector<std::vector<int>> graph;
    std::vector<int> dist;
    std::vector<bool> visited;
    std::vector<int> parent;

    void emitStep(std::vector<std::string>& steps, const std::string& action,
                  int u = -1, int v = -1, const std::string& msg = "") {
        std::ostringstream oss;
        oss << "{\"action\":\"" << action << "\",";
        if (u >= 0) oss << "\"u\":" << u << ",";
        if (v >= 0) oss << "\"v\":" << v << ",";
        oss << "\"message\":\"" << msg << "\",";
        oss << "\"dist\":[";
        for (int i = 0; i < n; i++) {
            if (i) oss << ",";
            if (dist[i] == INT_MAX) oss << "999999"; else oss << dist[i];
        }
        oss << "],\"visited\":[";
        for (int i = 0; i < n; i++) { if (i) oss << ","; oss << (visited[i] ? "true" : "false"); }
        oss << "]}";
        steps.push_back(oss.str());
    }

public:
    Dijkstra(int n, const std::vector<std::vector<int>>& g) : n(n), graph(g),
        dist(n, INT_MAX), visited(n, false), parent(n, -1) {}

    void run(int src, std::vector<std::string>& steps) {
        dist[src] = 0;
        emitStep(steps, "init", src, -1, "Initializing: distance to source " + std::to_string(src) + " = 0");

        for (int count = 0; count < n - 1; count++) {
            // Find min dist vertex
            int u = -1, minDist = INT_MAX;
            for (int v = 0; v < n; v++)
                if (!visited[v] && dist[v] < minDist) { minDist = dist[v]; u = v; }

            if (u == -1) break;
            visited[u] = 1;
            emitStep(steps, "visit", u, -1, "Visiting vertex " + std::to_string(u) + " (dist=" + std::to_string(dist[u]) + ")");

            for (int v = 0; v < n; v++) {
                if (!visited[v] && graph[u][v] != 0 && dist[u] != INT_MAX) {
                    int newDist = dist[u] + graph[u][v];
                    emitStep(steps, "relax", u, v,
                        "Relaxing edge " + std::to_string(u) + "→" + std::to_string(v) +
                        " : " + std::to_string(dist[u]) + "+" + std::to_string(graph[u][v]) + "=" + std::to_string(newDist));
                    if (newDist < dist[v]) {
                        dist[v] = newDist;
                        parent[v] = u;
                        emitStep(steps, "update", u, v,
                            "Updated dist[" + std::to_string(v) + "] = " + std::to_string(newDist));
                    }
                }
            }
        }
        emitStep(steps, "done", -1, -1, "Dijkstra complete");
    }
};

int main(int argc, char* argv[]) {
    std::string inputFile = (argc > 1) ? argv[1] : "input.txt";
    std::string outputFile = (argc > 2) ? argv[2] : "output.txt";

    std::ifstream fin(inputFile);
    if (!fin.is_open()) { std::cerr << "Cannot open: " << inputFile; return 1; }

    int n;
    fin >> n;
    std::vector<std::vector<int>> graph(n, std::vector<int>(n));
    for (int i = 0; i < n; i++)
        for (int j = 0; j < n; j++)
            fin >> graph[i][j];
    int src = 0;
    fin >> src;
    fin.close();

    Dijkstra dijk(n, graph);
    std::vector<std::string> steps;
    dijk.run(src, steps);

    std::ofstream fout(outputFile);
    fout << "[";
    for (size_t i = 0; i < steps.size(); i++) {
        if (i) fout << ",";
        fout << steps[i];
    }
    fout << "]";
    fout.close();
    return 0;
}
