/**
 * Prim's MST - C++ OOP Implementation
 * Outputs JSON steps for frontend visualization
 */
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>
#include <climits>

class PrimsMST {
private:
    int n;
    std::vector<std::vector<int>> graph;
    std::vector<int> parent, key;
    std::vector<bool> inMST;

    void emitStep(std::vector<std::string>& steps, const std::string& action,
                  int u = -1, int v = -1, const std::string& msg = "") {
        std::ostringstream oss;
        oss << "{\"action\":\"" << action << "\",";
        if (u >= 0) oss << "\"u\":" << u << ",";
        if (v >= 0) oss << "\"v\":" << v << ",";
        oss << "\"message\":\"" << msg << "\",";
        oss << "\"inMST\":[";
        for (int i = 0; i < n; i++) { if (i) oss << ","; oss << (inMST[i] ? "true" : "false"); }
        oss << "],\"parent\":[";
        for (int i = 0; i < n; i++) { if (i) oss << ","; oss << parent[i]; }
        oss << "]}";
        steps.push_back(oss.str());
    }

public:
    PrimsMST(int n, const std::vector<std::vector<int>>& g) : n(n), graph(g),
        parent(n, -1), key(n, INT_MAX), inMST(n, false) {}

    void run(std::vector<std::string>& steps) {
        key[0] = 0;
        emitStep(steps, "init", 0, -1, "Starting Prim's from vertex 0");

        for (int count = 0; count < n; count++) {
            // Pick min key vertex not yet in MST
            int u = -1, minKey = INT_MAX;
            for (int v = 0; v < n; v++)
                if (!inMST[v] && key[v] < minKey) { minKey = key[v]; u = v; }

            if (u == -1) break;
            inMST[u] = true;
            emitStep(steps, "addVertex", u, parent[u],
                "Added vertex " + std::to_string(u) +
                (parent[u] >= 0 ? " (edge " + std::to_string(parent[u]) + "-" + std::to_string(u) + " w=" + std::to_string(graph[u][parent[u]]) + ")" : " (start)"));

            for (int v = 0; v < n; v++) {
                if (graph[u][v] != 0 && !inMST[v]) {
                    emitStep(steps, "checkEdge", u, v,
                        "Checking edge " + std::to_string(u) + "→" + std::to_string(v) + " w=" + std::to_string(graph[u][v]));
                    if (graph[u][v] < key[v]) {
                        key[v] = graph[u][v];
                        parent[v] = u;
                        emitStep(steps, "updateKey", u, v,
                            "Updated key[" + std::to_string(v) + "] = " + std::to_string(graph[u][v]));
                    }
                }
            }
        }
        emitStep(steps, "done", -1, -1, "Prim's MST complete");
    }
};

int main(int argc, char* argv[]) {
    std::string inputFile = (argc > 1) ? argv[1] : "input.txt";
    std::string outputFile = (argc > 2) ? argv[2] : "output.txt";

    std::ifstream fin(inputFile);
    if (!fin.is_open()) { std::cerr << "Cannot open: " << inputFile; return 1; }

    int n; fin >> n;
    std::vector<std::vector<int>> graph(n, std::vector<int>(n));
    for (int i = 0; i < n; i++)
        for (int j = 0; j < n; j++)
            fin >> graph[i][j];
    fin.close();

    PrimsMST prims(n, graph);
    std::vector<std::string> steps;
    prims.run(steps);

    std::ofstream fout(outputFile);
    fout << "[";
    for (size_t i = 0; i < steps.size(); i++) {
        if (i) fout << ",";
        fout << steps[i];
    }
    fout << "]";
    fout.close();
    return 0;
}
