/**
 * Binary Search Tree - C++ OOP Implementation
 * Supports: insert, delete, search, inorder/preorder/postorder traversal
 * Outputs JSON steps with tree structure for frontend visualization
 */
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>
#include <algorithm>

struct TreeNode {
    int data;
    TreeNode* left;
    TreeNode* right;
    explicit TreeNode(int val) : data(val), left(nullptr), right(nullptr) {}
};

class BST {
private:
    TreeNode* root;

    // Serialize tree to JSON for visualization
    std::string serializeTree(TreeNode* node) const {
        if (!node) return "null";
        std::ostringstream oss;
        oss << "{\"val\":" << node->data
            << ",\"left\":" << serializeTree(node->left)
            << ",\"right\":" << serializeTree(node->right) << "}";
        return oss.str();
    }

    void emitStep(std::vector<std::string>& steps, const std::string& action,
                  int value = -1, const std::string& msg = "",
                  int highlight = -1) {
        std::ostringstream oss;
        oss << "{\"action\":\"" << action << "\",";
        if (value != -1) oss << "\"value\":" << value << ",";
        oss << "\"message\":\"" << msg << "\",";
        if (highlight >= 0) oss << "\"highlight\":" << highlight << ",";
        oss << "\"tree\":" << serializeTree(root) << "}";
        steps.push_back(oss.str());
    }

    TreeNode* insert(TreeNode* node, int val, std::vector<std::string>& steps) {
        if (!node) {
            TreeNode* newNode = new TreeNode(val);
            return newNode;
        }
        if (val < node->data) {
            emitStep(steps, "goLeft", val, "Going LEFT from " + std::to_string(node->data), node->data);
            node->left = insert(node->left, val, steps);
        } else if (val > node->data) {
            emitStep(steps, "goRight", val, "Going RIGHT from " + std::to_string(node->data), node->data);
            node->right = insert(node->right, val, steps);
        }
        return node;
    }

    TreeNode* findMin(TreeNode* node) {
        while (node->left) node = node->left;
        return node;
    }

    TreeNode* deleteNode(TreeNode* node, int val, std::vector<std::string>& steps) {
        if (!node) return nullptr;
        if (val < node->data) {
            node->left = deleteNode(node->left, val, steps);
        } else if (val > node->data) {
            node->right = deleteNode(node->right, val, steps);
        } else {
            emitStep(steps, "deleteFound", val, "Found node " + std::to_string(val) + " - deleting", val);
            if (!node->left) {
                TreeNode* tmp = node->right;
                delete node;
                return tmp;
            } else if (!node->right) {
                TreeNode* tmp = node->left;
                delete node;
                return tmp;
            }
            TreeNode* minRight = findMin(node->right);
            emitStep(steps, "replaceWith", minRight->data,
                "Replacing with inorder successor " + std::to_string(minRight->data), minRight->data);
            node->data = minRight->data;
            node->right = deleteNode(node->right, minRight->data, steps);
        }
        return node;
    }

    void inorder(TreeNode* node, std::vector<std::string>& steps) {
        if (!node) return;
        inorder(node->left, steps);
        emitStep(steps, "visit", node->data, "Visiting node " + std::to_string(node->data), node->data);
        inorder(node->right, steps);
    }

    bool search(TreeNode* node, int val, std::vector<std::string>& steps) {
        if (!node) {
            emitStep(steps, "notFound", val, std::to_string(val) + " not found in tree");
            return false;
        }
        emitStep(steps, "checking", val, "Checking node " + std::to_string(node->data), node->data);
        if (val == node->data) {
            emitStep(steps, "found", val, "Found " + std::to_string(val) + "!", val);
            return true;
        }
        if (val < node->data) return search(node->left, val, steps);
        return search(node->right, val, steps);
    }

    void freeTree(TreeNode* node) {
        if (!node) return;
        freeTree(node->left);
        freeTree(node->right);
        delete node;
    }

public:
    BST() : root(nullptr) {}
    ~BST() { freeTree(root); }

    void insert(int val, std::vector<std::string>& steps) {
        emitStep(steps, "startInsert", val, "Inserting " + std::to_string(val));
        root = insert(root, val, steps);
        emitStep(steps, "inserted", val, std::to_string(val) + " inserted successfully", val);
    }

    void deleteVal(int val, std::vector<std::string>& steps) {
        emitStep(steps, "startDelete", val, "Deleting " + std::to_string(val));
        root = deleteNode(root, val, steps);
        emitStep(steps, "deleted", val, "Deletion complete");
    }

    void inorderTraversal(std::vector<std::string>& steps) {
        emitStep(steps, "startTraversal", -1, "Starting inorder traversal (Left → Root → Right)");
        inorder(root, steps);
        emitStep(steps, "traversalEnd", -1, "Inorder traversal complete");
    }

    void searchVal(int val, std::vector<std::string>& steps) {
        emitStep(steps, "startSearch", val, "Searching for " + std::to_string(val));
        search(root, val, steps);
    }
};

int main(int argc, char* argv[]) {
    std::string inputFile = (argc > 1) ? argv[1] : "input.txt";
    std::string outputFile = (argc > 2) ? argv[2] : "output.txt";

    std::ifstream fin(inputFile);
    if (!fin.is_open()) { std::cerr << "Cannot open: " << inputFile; return 1; }

    BST bst;
    std::vector<std::string> steps;
    std::string cmd;
    int val;

    while (fin >> cmd) {
        if (cmd == "insert") {
            if (fin >> val) bst.insert(val, steps);
        } else if (cmd == "delete") {
            if (fin >> val) bst.deleteVal(val, steps);
        } else if (cmd == "search") {
            if (fin >> val) bst.searchVal(val, steps);
        } else if (cmd == "inorder") {
            bst.inorderTraversal(steps);
        }
    }
    fin.close();

    std::ofstream fout(outputFile);
    fout << "[";
    for (size_t i = 0; i < steps.size(); i++) {
        if (i) fout << ",";
        fout << steps[i];
    }
    fout << "]";
    fout.close();
    return 0;
}
