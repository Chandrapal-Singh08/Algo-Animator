/**
 * Queue - C++ OOP Implementation
 * Supports: enqueue, dequeue, front, isEmpty
 * Outputs JSON steps for frontend visualization
 */
#include <iostream>
#include <fstream>
#include <sstream>
#include <deque>
#include <vector>
#include <string>

class Queue {
private:
    std::deque<int> data;
    static const int MAX_SIZE = 100;

    void emitStep(std::vector<std::string>& steps, const std::string& action,
                  int value = -1, const std::string& msg = "") const {
        std::ostringstream oss;
        oss << "{\"action\":\"" << action << "\",";
        if (value != -1) oss << "\"value\":" << value << ",";
        oss << "\"message\":\"" << msg << "\",";
        oss << "\"state\":[";
        bool first = true;
        for (int x : data) {
            if (!first) oss << ",";
            oss << x;
            first = false;
        }
        oss << "]}";
        steps.push_back(oss.str());
    }

public:
    bool enqueue(int val, std::vector<std::string>& steps) {
        if ((int)data.size() >= MAX_SIZE) {
            emitStep(steps, "overflow", val, "Queue is full! Cannot enqueue " + std::to_string(val));
            return false;
        }
        data.push_back(val);
        emitStep(steps, "enqueue", val, "Enqueued " + std::to_string(val) + " at the rear");
        return true;
    }

    bool dequeue(std::vector<std::string>& steps) {
        if (data.empty()) {
            emitStep(steps, "underflow", -1, "Queue is empty! Cannot dequeue");
            return false;
        }
        int val = data.front();
        data.pop_front();
        emitStep(steps, "dequeue", val, "Dequeued " + std::to_string(val) + " from the front");
        return true;
    }

    void front(std::vector<std::string>& steps) const {
        if (data.empty()) {
            const_cast<Queue*>(this)->emitStep(const_cast<std::vector<std::string>&>(steps),
                "empty", -1, "Queue is empty");
            return;
        }
        const_cast<Queue*>(this)->emitStep(const_cast<std::vector<std::string>&>(steps),
            "front", data.front(), "Front element is " + std::to_string(data.front()));
    }

    bool isEmpty() const { return data.empty(); }
    int size() const { return (int)data.size(); }
};

int main(int argc, char* argv[]) {
    std::string inputFile = (argc > 1) ? argv[1] : "input.txt";
    std::string outputFile = (argc > 2) ? argv[2] : "output.txt";

    std::ifstream fin(inputFile);
    if (!fin.is_open()) { std::cerr << "Cannot open: " << inputFile; return 1; }

    Queue queue;
    std::vector<std::string> steps;
    std::string cmd;
    int val;

    while (fin >> cmd) {
        if (cmd == "enqueue") {
            if (fin >> val) queue.enqueue(val, steps);
        } else if (cmd == "dequeue") {
            queue.dequeue(steps);
        } else if (cmd == "front") {
            queue.front(steps);
        }
    }
    fin.close();

    std::ofstream fout(outputFile);
    fout << "[";
    for (size_t i = 0; i < steps.size(); i++) {
        if (i) fout << ",";
        fout << steps[i];
    }
    fout << "]";
    fout.close();
    return 0;
}
