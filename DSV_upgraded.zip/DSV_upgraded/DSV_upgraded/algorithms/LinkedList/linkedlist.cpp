/**
 * Linked List - C++ OOP Implementation
 * Supports: insertFront, insertBack, insertAt, delete, search, traverse
 * Outputs JSON steps for frontend visualization
 */
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>
#include <memory>

struct Node {
    int data;
    Node* next;
    explicit Node(int val) : data(val), next(nullptr) {}
};

class LinkedList {
private:
    Node* head;
    int size_;

    std::string serializeState() const {
        std::ostringstream oss;
        oss << "[";
        Node* cur = head;
        bool first = true;
        while (cur) {
            if (!first) oss << ",";
            oss << cur->data;
            first = false;
            cur = cur->next;
        }
        oss << "]";
        return oss.str();
    }

    void emitStep(std::vector<std::string>& steps, const std::string& action,
                  int value = -1, const std::string& msg = "",
                  int highlight = -1) const {
        std::ostringstream oss;
        oss << "{\"action\":\"" << action << "\",";
        if (value != -1) oss << "\"value\":" << value << ",";
        oss << "\"message\":\"" << msg << "\",";
        if (highlight >= 0) oss << "\"highlight\":" << highlight << ",";
        oss << "\"state\":" << serializeState() << "}";
        steps.push_back(oss.str());
    }

public:
    LinkedList() : head(nullptr), size_(0) {}

    ~LinkedList() {
        Node* cur = head;
        while (cur) {
            Node* next = cur->next;
            delete cur;
            cur = next;
        }
    }

    void insertFront(int val, std::vector<std::string>& steps) {
        Node* newNode = new Node(val);
        newNode->next = head;
        head = newNode;
        size_++;
        emitStep(steps, "insertFront", val, "Inserted " + std::to_string(val) + " at the front", 0);
    }

    void insertBack(int val, std::vector<std::string>& steps) {
        Node* newNode = new Node(val);
        if (!head) {
            head = newNode;
        } else {
            Node* cur = head;
            int idx = 0;
            while (cur->next) { cur = cur->next; idx++; }
            cur->next = newNode;
        }
        size_++;
        emitStep(steps, "insertBack", val, "Inserted " + std::to_string(val) + " at the back", size_ - 1);
    }

    bool deleteNode(int val, std::vector<std::string>& steps) {
        Node *cur = head, *prev = nullptr;
        int idx = 0;
        while (cur && cur->data != val) {
            prev = cur;
            cur = cur->next;
            idx++;
        }
        if (!cur) {
            emitStep(steps, "notFound", val, std::to_string(val) + " not found in list");
            return false;
        }
        if (!prev) head = cur->next;
        else prev->next = cur->next;
        delete cur;
        size_--;
        emitStep(steps, "delete", val, "Deleted node with value " + std::to_string(val));
        return true;
    }

    bool search(int val, std::vector<std::string>& steps) {
        Node* cur = head;
        int idx = 0;
        while (cur) {
            emitStep(steps, "searching", val,
                "Checking node " + std::to_string(cur->data) + " at index " + std::to_string(idx),
                idx);
            if (cur->data == val) {
                emitStep(steps, "found", val, "Found " + std::to_string(val) + " at index " + std::to_string(idx), idx);
                return true;
            }
            cur = cur->next;
            idx++;
        }
        emitStep(steps, "notFound", val, std::to_string(val) + " not found in list");
        return false;
    }

    void traverse(std::vector<std::string>& steps) {
        Node* cur = head;
        int idx = 0;
        while (cur) {
            emitStep(steps, "traverse", cur->data,
                "Visiting node " + std::to_string(cur->data) + " at index " + std::to_string(idx),
                idx);
            cur = cur->next;
            idx++;
        }
        emitStep(steps, "traverseEnd", -1, "Traversal complete");
    }
};

int main(int argc, char* argv[]) {
    std::string inputFile = (argc > 1) ? argv[1] : "input.txt";
    std::string outputFile = (argc > 2) ? argv[2] : "output.txt";

    std::ifstream fin(inputFile);
    if (!fin.is_open()) { std::cerr << "Cannot open: " << inputFile; return 1; }

    LinkedList ll;
    std::vector<std::string> steps;
    std::string cmd;
    int val;

    while (fin >> cmd) {
        if (cmd == "insert" || cmd == "insertBack") {
            if (fin >> val) ll.insertBack(val, steps);
        } else if (cmd == "insertFront") {
            if (fin >> val) ll.insertFront(val, steps);
        } else if (cmd == "delete") {
            if (fin >> val) ll.deleteNode(val, steps);
        } else if (cmd == "search") {
            if (fin >> val) ll.search(val, steps);
        } else if (cmd == "traverse") {
            ll.traverse(steps);
        }
    }
    fin.close();

    std::ofstream fout(outputFile);
    fout << "[";
    for (size_t i = 0; i < steps.size(); i++) {
        if (i) fout << ",";
        fout << steps[i];
    }
    fout << "]";
    fout.close();
    return 0;
}
