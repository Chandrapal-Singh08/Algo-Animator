/**
 * Dijkstra Visualizer JS
 */

const DIJKSTRA_CODE = [
  `void dijkstra(int src) {`,
  `  dist.assign(n, INT_MAX);`,
  `  visited.assign(n, false);`,
  `  dist[src] = 0;               // source = 0`,
  `  for (int count = 0; count < n-1; count++) {`,
  `    int u = minDist();          // pick unvisited min`,
  `    visited[u] = true;          // mark visited`,
  `    for (int v = 0; v < n; v++) {`,
  `      if (!visited[v] && graph[u][v]) {`,
  `        int nd = dist[u] + graph[u][v];`,
  `        if (nd < dist[v])       // relaxation`,
  `          dist[v] = nd;         // update dist`,
  `      }`,
  `    }`,
  `  }`,
  `}`,
];

const DIJKSTRA_ACTION_LINE = {
  init:4, visit:6, relax:10, update:12, done:16
};

let dijkMatrix = null, dijkN = 0;
let dijkSteps = [], dijkPlayer = null;
let dijkVisited = new Set(), dijkMST = [], dijkDist = [];

function parseDijkInput() {
  const raw = document.getElementById('matrix-input').value.trim();
  const nums = raw.split(/\s+/).map(Number);
  const n = nums[0];
  const mat = [];
  for (let i = 0; i < n; i++) {
    mat.push(nums.slice(1 + i * n, 1 + (i + 1) * n));
  }
  return { n, mat };
}

function onDijkStep(step, idx, total) {
  renderCode('code-view', DIJKSTRA_CODE, DIJKSTRA_ACTION_LINE[step.action] || -1);
  setMsg(step.message || '', step.action === 'done' ? 'success' : 'info');
  updateStepCounter(dijkPlayer);

  if (step.visited)  dijkVisited = new Set(step.visited.map((v,i)=>v?i:-1).filter(i=>i>=0));
  if (step.dist)     dijkDist = step.dist;

  const activeEdge = (step.u >= 0 && step.v >= 0) ? { u: step.u, v: step.v } : null;
  const distLabels = dijkDist.map(d => d >= 999999 ? '∞' : String(d));

  drawGraph('graph-svg', dijkN, dijkMatrix, {
    visitedNodes: dijkVisited,
    activeEdge,
    highlightNode: step.u >= 0 ? step.u : -1,
    distLabels,
  });
  renderDistTable('dist-table-wrap', dijkDist, dijkN);
  updatePlayBtn(dijkPlayer, 'btn-play');
}

async function doRun() {
  try {
    const { n, mat } = parseDijkInput();
    const src = parseInt(document.getElementById('src-input').value) || 0;
    dijkN = n; dijkMatrix = mat;

    // Build input string
    let inp = `${n}\n`;
    mat.forEach(row => inp += row.join(' ') + '\n');
    inp += src;

    setMsg('Running Dijkstra…', 'info');
    const res = await DSV.run('dijkstra', inp);
    if (res.error) { setMsg('Error: ' + res.error, 'error'); return; }

    dijkSteps = res.steps;
    dijkVisited = new Set(); dijkDist = []; dijkMST = [];

    dijkPlayer = new StepPlayer({
      steps: dijkSteps,
      onStep: onDijkStep,
      onDone: () => setMsg('✅ Dijkstra complete!', 'success'),
      getSpeed: () => 1100 - parseInt(document.getElementById('speed-range').value),
    });

    ['btn-play','btn-prev','btn-next'].forEach(id => {
      const b = document.getElementById(id); if (b) b.disabled = false;
    });

    // Draw initial graph
    drawGraph('graph-svg', dijkN, dijkMatrix, {});
    dijkPlayer.reset();

  } catch(e) { setMsg('Parse error — check matrix format.', 'error'); }
}

function togglePlay() { dijkPlayer && dijkPlayer.toggle(); updatePlayBtn(dijkPlayer, 'btn-play'); }
function stepNext()   { dijkPlayer && (dijkPlayer.pause(), dijkPlayer.next()); updatePlayBtn(dijkPlayer,'btn-play'); }
function stepPrev()   { dijkPlayer && (dijkPlayer.pause(), dijkPlayer.prev()); updatePlayBtn(dijkPlayer,'btn-play'); }

function loadExample() {
  document.getElementById('matrix-input').value =
`5
0 10 0 30 100
10 0 50 0 0
0 50 0 20 10
30 0 20 0 60
100 0 10 60 0`;
  document.getElementById('src-input').value = '0';
}

// ── Init ──────────────────────────────────────────────────────────────────────
renderCode('code-view', DIJKSTRA_CODE);
renderComplexity('dijkstra', 'dijkstra');
loadExample();
