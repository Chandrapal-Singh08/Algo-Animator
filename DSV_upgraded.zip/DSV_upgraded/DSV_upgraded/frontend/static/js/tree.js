/**
 * BST Visualizer JS — SVG tree drawing with step highlighting
 */

const TREE_CODE = [
  `// BST — C++ OOP Implementation`,
  `struct Node { int data; Node *left, *right; };`,
  ``,
  `Node* insert(Node* node, int val) {`,
  `  if (!node) return new Node(val);  // create leaf`,
  `  if (val < node->data)`,
  `    node->left = insert(node->left, val);  // go left`,
  `  else if (val > node->data)`,
  `    node->right = insert(node->right, val); // go right`,
  `  return node;`,
  `}`,
  ``,
  `Node* deleteNode(Node* node, int val) {`,
  `  if (!node) return nullptr;`,
  `  if (val < node->data) node->left = deleteNode(node->left, val);`,
  `  else if (val > node->data) node->right = deleteNode(node->right, val);`,
  `  else {                              // found!`,
  `    if (!node->left) return node->right;  // no left child`,
  `    if (!node->right) return node->left;  // no right child`,
  `    Node* succ = findMin(node->right);    // inorder successor`,
  `    node->data = succ->data;`,
  `    node->right = deleteNode(node->right, succ->data);`,
  `  }`,
  `  return node;`,
  `}`,
  ``,
  `bool search(Node* node, int val) {`,
  `  if (!node) return false;`,
  `  if (val == node->data) return true;  // found`,
  `  if (val < node->data) return search(node->left, val);`,
  `  return search(node->right, val);`,
  `}`,
];

const ACTION_LINE = {
  startInsert:5, goLeft:6, goRight:8, inserted:5,
  startDelete:13, deleteFound:17, replaceWith:20,
  startSearch:27, checking:28, found:29, notFound:28,
  visit:29,
};

// ── Tree state ────────────────────────────────────────────────────────────────
let treeRoot = null;  // JS mirror of tree for drawing
let highlightVal = -1;

// ── SVG Tree Renderer ─────────────────────────────────────────────────────────
const SVG_NS = 'http://www.w3.org/2000/svg';
const NODE_R = 22;

function treeLayout(node, depth = 0, left = 0, right = 1) {
  if (!node) return null;
  const mid = (left + right) / 2;
  return {
    val: node.val,
    x: mid,
    y: depth,
    left: treeLayout(node.left, depth + 1, left, mid),
    right: treeLayout(node.right, depth + 1, mid, right),
  };
}

function countDepth(node) {
  if (!node) return 0;
  return 1 + Math.max(countDepth(node.left), countDepth(node.right));
}

function drawTree(root, hlVal = -1) {
  const svg = document.getElementById('tree-svg');
  svg.innerHTML = '';
  if (!root) return;

  const depth = countDepth(root);
  const W = Math.max(700, Math.pow(2, depth) * 60);
  const H = Math.max(300, depth * 80 + 60);
  svg.setAttribute('width', W);
  svg.setAttribute('height', H);

  const layout = treeLayout(root, 0, 0, 1);

  function drawEdges(node) {
    if (!node) return;
    const px = node.x * W;
    const py = node.y * 80 + 40;
    if (node.left) {
      const cx = node.left.x * W, cy = node.left.y * 80 + 40;
      const line = document.createElementNS(SVG_NS, 'line');
      line.setAttribute('x1', px); line.setAttribute('y1', py);
      line.setAttribute('x2', cx); line.setAttribute('y2', cy);
      line.setAttribute('stroke', '#2d3748'); line.setAttribute('stroke-width', '2');
      svg.appendChild(line);
      drawEdges(node.left);
    }
    if (node.right) {
      const cx = node.right.x * W, cy = node.right.y * 80 + 40;
      const line = document.createElementNS(SVG_NS, 'line');
      line.setAttribute('x1', px); line.setAttribute('y1', py);
      line.setAttribute('x2', cx); line.setAttribute('y2', cy);
      line.setAttribute('stroke', '#2d3748'); line.setAttribute('stroke-width', '2');
      svg.appendChild(line);
      drawEdges(node.right);
    }
  }

  function drawNodes(node) {
    if (!node) return;
    const cx = node.x * W;
    const cy = node.y * 80 + 40;
    const isHL = node.val === hlVal;

    const circle = document.createElementNS(SVG_NS, 'circle');
    circle.setAttribute('cx', cx); circle.setAttribute('cy', cy);
    circle.setAttribute('r', NODE_R);
    circle.setAttribute('fill', isHL ? '#f59e0b' : '#1e40af');
    circle.setAttribute('stroke', isHL ? '#fbbf24' : '#3b82f6');
    circle.setAttribute('stroke-width', '2');
    if (isHL) circle.setAttribute('filter', 'drop-shadow(0 0 8px #f59e0b)');
    svg.appendChild(circle);

    const text = document.createElementNS(SVG_NS, 'text');
    text.setAttribute('x', cx); text.setAttribute('y', cy + 5);
    text.setAttribute('text-anchor', 'middle');
    text.setAttribute('fill', 'white');
    text.setAttribute('font-size', '13');
    text.setAttribute('font-weight', 'bold');
    text.setAttribute('font-family', 'Inter, sans-serif');
    text.textContent = node.val;
    svg.appendChild(text);

    drawNodes(node.left);
    drawNodes(node.right);
  }

  drawEdges(layout);
  drawNodes(layout);
}

// ── Step handling ─────────────────────────────────────────────────────────────
async function applyStep(step) {
  const line = ACTION_LINE[step.action] || -1;
  renderCode('code-view', TREE_CODE, line);

  const typeMap = {
    inserted:'success', found:'success', notFound:'error',
    deleteFound:'warn', checking:'info', goLeft:'info', goRight:'info',
    replaceWith:'warn', visit:'info', traversalEnd:'success'
  };
  setMsg(step.message, typeMap[step.action] || '');

  if (step.tree !== undefined) treeRoot = step.tree;
  highlightVal = (step.highlight !== undefined) ? step.highlight : -1;
  drawTree(treeRoot, highlightVal);
  await new Promise(r => setTimeout(r, 50));
}

async function runCommand(cmd) {
  const res = await DSV.run('tree', cmd);
  if (res.error) { setMsg('Error: ' + res.error, 'error'); return; }
  for (const step of res.steps) {
    await applyStep(step);
    await new Promise(r => setTimeout(r, 500));
  }
}

// ── Rebuild cmd from current tree state ──────────────────────────────────────
function inorderValues(node, out = []) {
  if (!node) return out;
  inorderValues(node.left, out);
  out.push(node.val);
  inorderValues(node.right, out);
  return out;
}
// We rebuild by re-inserting in the order that preserves BST shape
// (BFS order is safest to reconstruct)
function bfsOrder(root) {
  if (!root) return [];
  const q = [root], out = [];
  while (q.length) {
    const n = q.shift();
    out.push(n.val);
    if (n.left)  q.push(n.left);
    if (n.right) q.push(n.right);
  }
  return out;
}

function buildStateCmd(extra = '') {
  const vals = bfsOrder(treeRoot);
  const base = vals.map(v => `insert ${v}`).join('\n');
  return base + (extra ? '\n' + extra : '');
}

// ── User Actions ──────────────────────────────────────────────────────────────
async function doInsert() {
  const v = document.getElementById('val-input').value.trim();
  if (!v) { setMsg('Enter a value first.', 'warn'); return; }
  document.getElementById('op-select').value = 'insert'; updateComplexity();
  await runCommand(buildStateCmd(`insert ${v}`));
}

async function doDelete() {
  const v = document.getElementById('val-input').value.trim();
  if (!v) { setMsg('Enter a value to delete.', 'warn'); return; }
  document.getElementById('op-select').value = 'delete'; updateComplexity();
  await runCommand(buildStateCmd(`delete ${v}`));
}

async function doSearch() {
  const v = document.getElementById('val-input').value.trim();
  if (!v) { setMsg('Enter a value to search.', 'warn'); return; }
  document.getElementById('op-select').value = 'search'; updateComplexity();
  await runCommand(buildStateCmd(`search ${v}`));
}

async function doInorder() {
  document.getElementById('op-select').value = 'inorder'; updateComplexity();
  await runCommand(buildStateCmd('inorder'));
}

function doReset() {
  treeRoot = null;
  drawTree(null);
  setMsg('Tree cleared.', 'info');
  renderCode('code-view', TREE_CODE);
}

function updateComplexity() {
  renderComplexity('tree', document.getElementById('op-select').value);
}

// ── Init ──────────────────────────────────────────────────────────────────────
renderCode('code-view', TREE_CODE);
renderComplexity('tree', 'insert');
