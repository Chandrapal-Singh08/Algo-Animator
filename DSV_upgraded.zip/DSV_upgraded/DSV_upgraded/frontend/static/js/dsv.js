/**
 * DSV Shared Utilities
 * ─ API calls, step playback engine, Chart.js complexity graphs, code renderer
 */

// ── API ───────────────────────────────────────────────────────────────────────
const DSV = {
  async run(algorithm, input) {
    const res = await fetch('/api/run', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ algorithm, input })
    });
    return res.json();
  }
};

// ── Playback Engine ───────────────────────────────────────────────────────────
class StepPlayer {
  constructor({ steps, onStep, onDone, getSpeed }) {
    this.steps = steps;
    this.onStep = onStep;
    this.onDone = onDone;
    this.getSpeed = getSpeed || (() => 600);
    this.idx = -1;
    this._timer = null;
    this._playing = false;
  }

  get total() { return this.steps.length; }
  get current() { return this.idx; }

  _render() {
    if (this.idx >= 0 && this.idx < this.total)
      this.onStep(this.steps[this.idx], this.idx, this.total);
  }

  next() {
    if (this.idx < this.total - 1) { this.idx++; this._render(); }
    else if (this.onDone) this.onDone();
  }

  prev() {
    if (this.idx > 0) { this.idx--; this._render(); }
  }

  reset() {
    this.pause();
    this.idx = -1;
    if (this.total > 0) { this.idx = 0; this._render(); }
  }

  play() {
    if (this._playing) return;
    this._playing = true;
    const tick = () => {
      if (!this._playing) return;
      this.next();
      if (this.idx < this.total - 1)
        this._timer = setTimeout(tick, this.getSpeed());
      else {
        this._playing = false;
        if (this.onDone) this.onDone();
      }
    };
    this._timer = setTimeout(tick, this.getSpeed());
  }

  pause() {
    this._playing = false;
    clearTimeout(this._timer);
  }

  toggle() { this._playing ? this.pause() : this.play(); }
  isPlaying() { return this._playing; }
}

// ── Complexity Data ───────────────────────────────────────────────────────────
const COMPLEXITY = {
  stack: {
    operations: {
      push:   { best:'O(1)', avg:'O(1)', worst:'O(1)', space:'O(1)' },
      pop:    { best:'O(1)', avg:'O(1)', worst:'O(1)', space:'O(1)' },
      peek:   { best:'O(1)', avg:'O(1)', worst:'O(1)', space:'O(1)' },
    },
    default: 'push'
  },
  queue: {
    operations: {
      enqueue: { best:'O(1)', avg:'O(1)', worst:'O(1)', space:'O(1)' },
      dequeue: { best:'O(1)', avg:'O(1)', worst:'O(1)', space:'O(1)' },
    },
    default: 'enqueue'
  },
  linkedlist: {
    operations: {
      insertFront: { best:'O(1)', avg:'O(1)',  worst:'O(1)',  space:'O(1)' },
      insertBack:  { best:'O(n)', avg:'O(n)',  worst:'O(n)',  space:'O(1)' },
      delete:      { best:'O(1)', avg:'O(n)',  worst:'O(n)',  space:'O(1)' },
      search:      { best:'O(1)', avg:'O(n)',  worst:'O(n)',  space:'O(1)' },
    },
    default: 'search'
  },
  tree: {
    operations: {
      insert:  { best:'O(log n)', avg:'O(log n)', worst:'O(n)', space:'O(n)' },
      delete:  { best:'O(log n)', avg:'O(log n)', worst:'O(n)', space:'O(n)' },
      search:  { best:'O(1)',     avg:'O(log n)', worst:'O(n)', space:'O(n)' },
      inorder: { best:'O(n)',     avg:'O(n)',      worst:'O(n)', space:'O(n)' },
    },
    default: 'search'
  },
  dijkstra: {
    operations: {
      dijkstra: { best:'O(V²)', avg:'O(V²)', worst:'O(V²)', space:'O(V)' }
    },
    default: 'dijkstra'
  },
  prims: {
    operations: {
      prims: { best:'O(V²)', avg:'O(V²)', worst:'O(V²)', space:'O(V+E)' }
    },
    default: 'prims'
  },
  kruskal: {
    operations: {
      kruskal: { best:'O(E log E)', avg:'O(E log E)', worst:'O(E log E)', space:'O(E+V)' }
    },
    default: 'kruskal'
  },
  sorting: {
    operations: {
      bubble:    { best:'O(n)',   avg:'O(n²)',    worst:'O(n²)',    space:'O(1)' },
      insertion: { best:'O(n)',   avg:'O(n²)',    worst:'O(n²)',    space:'O(1)' },
      selection: { best:'O(n²)',  avg:'O(n²)',    worst:'O(n²)',    space:'O(1)' },
      merge:     { best:'O(n log n)', avg:'O(n log n)', worst:'O(n log n)', space:'O(n)' },
      quick:     { best:'O(n log n)', avg:'O(n log n)', worst:'O(n²)',      space:'O(log n)' },
    },
    default: 'bubble'
  }
};

// Map complexity notation to numeric score for bar chart
function complexityScore(c) {
  const map = {
    'O(1)':1,'O(log n)':2,'O(n)':3,'O(n log n)':4,'O(n²)':5,
    'O(V)':3,'O(V²)':5,'O(E)':3,'O(E log E)':4,'O(E+V)':3,'O(V+E)':3,'O(n)':3
  };
  return map[c] || 3;
}

// ── Complexity Charts ─────────────────────────────────────────────────────────
let _tcChart = null, _scChart = null;

function renderComplexity(ds, op) {
  const info = COMPLEXITY[ds];
  if (!info) return;
  const data = info.operations[op] || info.operations[info.default];
  if (!data) return;

  const tcEl = document.getElementById('tc-chart');
  const scEl = document.getElementById('sc-chart');
  const tbl  = document.getElementById('complexity-table-body');

  if (!tcEl || !scEl) return;

  const tcData = {
    labels: ['Best', 'Avg', 'Worst'],
    datasets: [{
      label: 'Time',
      data: [complexityScore(data.best), complexityScore(data.avg), complexityScore(data.worst)],
      backgroundColor: ['rgba(16,185,129,.7)', 'rgba(245,158,11,.7)', 'rgba(239,68,68,.7)'],
      borderColor:     ['#10b981','#f59e0b','#ef4444'],
      borderWidth: 2,
      borderRadius: 5,
    }]
  };

  const scData = {
    labels: ['Space'],
    datasets: [{
      label: 'Space',
      data: [complexityScore(data.space)],
      backgroundColor: ['rgba(139,92,246,.7)'],
      borderColor: ['#8b5cf6'],
      borderWidth: 2,
      borderRadius: 5,
    }]
  };

  const opts = (maxVal) => ({
    responsive: true,
    maintainAspectRatio: false,
    plugins: { legend: { display: false } },
    scales: {
      x: { ticks: { color: '#94a3b8', font: { size: 10 } }, grid: { color: '#1a2235' } },
      y: {
        ticks: { color: '#94a3b8', font: { size: 9 },
          callback: v => ['','O(1)','O(log n)','O(n)','O(n log n)','O(n²)'][v] || v
        },
        grid: { color: '#1a2235' },
        min: 0, max: 6, stepSize: 1
      }
    }
  });

  if (_tcChart) _tcChart.destroy();
  _tcChart = new Chart(tcEl, { type: 'bar', data: tcData, options: opts(6) });

  if (_scChart) _scChart.destroy();
  _scChart = new Chart(scEl, { type: 'bar', data: scData, options: opts(6) });

  if (tbl) {
    tbl.innerHTML = `
      <tr><td>${op}</td>
          <td class="tc-best">${data.best}</td>
          <td class="tc-avg">${data.avg}</td>
          <td class="tc-worst">${data.worst}</td>
          <td style="color:var(--accent2)">${data.space}</td>
      </tr>`;
  }
}

// ── Code Renderer ─────────────────────────────────────────────────────────────
function renderCode(containerId, lines, highlightLine = -1) {
  const el = document.getElementById(containerId);
  if (!el) return;
  el.innerHTML = lines.map((line, i) => {
    const hl = (i + 1 === highlightLine) ? ' highlighted' : '';
    return `<div class="code-line${hl}">
      <span class="line-num">${String(i+1).padStart(2,' ')}</span>
      <span class="code-text">${syntaxHL(line)}</span>
    </div>`;
  }).join('');

  if (highlightLine > 0) {
    const hlEl = el.querySelector('.highlighted');
    if (hlEl) hlEl.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
  }
}

function syntaxHL(line) {
  // Escape HTML first
  line = line.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
  // Comments
  line = line.replace(/(\/\/.*$)/g, '<span class="cm">$1</span>');
  // Strings
  line = line.replace(/(".*?")/g, '<span class="str">$1</span>');
  // Keywords
  const kws = /\b(void|int|bool|return|while|for|if|else|class|struct|auto|const|static|new|delete|true|false|nullptr|string|vector|using|namespace|std|public|private)\b/g;
  line = line.replace(kws, '<span class="kw">$1</span>');
  // Types
  const tys = /\b(int|bool|char|float|double|size_t|uint32_t)\b/g;
  line = line.replace(tys, '<span class="ty">$1</span>');
  // Numbers
  line = line.replace(/\b(\d+)\b/g, '<span class="num">$1</span>');
  return line;
}

// ── Playback Button Helpers ───────────────────────────────────────────────────
function updatePlayBtn(player, btnId = 'btn-play') {
  const btn = document.getElementById(btnId);
  if (btn) btn.textContent = player.isPlaying() ? '⏸ Pause' : '▶ Play';
}

function updateStepCounter(player, id = 'step-counter') {
  const el = document.getElementById(id);
  if (el) el.textContent = `Step ${player.current + 1} / ${player.total}`;
}

function setMsg(msg, type = '') {
  const el = document.getElementById('msg-bar');
  if (!el) return;
  el.className = 'msg-bar' + (type ? ' ' + type : '');
  el.textContent = msg;
}
