/**
 * Stack Visualizer JS
 * Handles UI interactions, calls backend, animates visualization
 */

// ── C++ Code Lines ────────────────────────────────────────────────────────────
const STACK_CODE = [
  `// Stack — C++ OOP Implementation`,
  `class Stack {`,
  `  vector<int> data;`,
  `public:`,
  `  bool push(int val) {`,
  `    if (data.size() >= MAX) return false; // overflow`,
  `    data.push_back(val);   // add to top`,
  `    return true;`,
  `  }`,
  `  bool pop() {`,
  `    if (data.empty()) return false; // underflow`,
  `    data.pop_back();        // remove top`,
  `    return true;`,
  `  }`,
  `  int peek() const {`,
  `    return data.back();     // view top`,
  `  }`,
  `  bool isEmpty() const { return data.empty(); }`,
  `};`,
];

// Line hints per action
const ACTION_LINE = {
  push:      5,
  overflow:  6,
  pop:       11,
  underflow: 12,
  peek:      16,
  empty:     17,
};

// ── State ─────────────────────────────────────────────────────────────────────
let pendingSteps = [];   // queued from backend
let stackState   = [];   // current rendered state

// ── Render ────────────────────────────────────────────────────────────────────
function renderStack(state, highlightTop = false) {
  const vis = document.getElementById('stack-vis');
  vis.innerHTML = '';
  state.forEach((val, i) => {
    const box = document.createElement('div');
    box.className = 'stack-item' + (highlightTop && i === state.length - 1 ? ' highlight' : '');
    box.textContent = val;
    vis.appendChild(box);
  });
}

async function applyStep(step) {
  const line = ACTION_LINE[step.action] || -1;
  renderCode('code-view', STACK_CODE, line);

  const typeMap = {
    push:      'success',
    pop:       'warn',
    peek:      'info',
    overflow:  'error',
    underflow: 'error',
    empty:     'info',
  };
  setMsg(step.message, typeMap[step.action] || '');

  const hl = ['push', 'peek'].includes(step.action);
  renderStack(step.state || stackState, hl);
  if (step.state) stackState = [...step.state];

  await sleep(50);
}

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

// ── Backend Calls ─────────────────────────────────────────────────────────────
async function runCommand(cmd) {
  const res = await DSV.run('stack', cmd);
  if (res.error) { setMsg('Error: ' + res.error, 'error'); return; }
  for (const step of res.steps) {
    await applyStep(step);
    await sleep(350);
  }
}

async function doPush() {
  const v = document.getElementById('val-input').value.trim();
  if (!v) { setMsg('Enter a value first.', 'warn'); return; }
  document.getElementById('op-select').value = 'push';
  updateComplexity();
  // Rebuild full state command to keep server stateless
  const cmds = stackState.map(x => `push ${x}`).join('\n') + `\npush ${v}`;
  await runCommand(cmds);
}

async function doPop() {
  if (stackState.length === 0) { setMsg('Stack is empty!', 'error'); return; }
  document.getElementById('op-select').value = 'pop';
  updateComplexity();
  const cmds = stackState.map(x => `push ${x}`).join('\n') + '\npop';
  await runCommand(cmds);
}

async function doPeek() {
  if (stackState.length === 0) { setMsg('Stack is empty!', 'error'); return; }
  document.getElementById('op-select').value = 'peek';
  updateComplexity();
  const cmds = stackState.map(x => `push ${x}`).join('\n') + '\npeek';
  await runCommand(cmds);
}

function doReset() {
  stackState = [];
  renderStack([]);
  setMsg('Stack cleared.', 'info');
  renderCode('code-view', STACK_CODE);
}

function updateComplexity() {
  const op = document.getElementById('op-select').value;
  renderComplexity('stack', op);
}

// ── Init ──────────────────────────────────────────────────────────────────────
renderCode('code-view', STACK_CODE);
renderComplexity('stack', 'push');
