/**
 * Linked List Visualizer JS
 */

const LL_CODE = [
  `// LinkedList — C++ OOP Implementation`,
  `struct Node { int data; Node* next; };`,
  ``,
  `void insertBack(int val) {`,
  `  Node* n = new Node(val);`,
  `  if (!head) { head = n; return; }`,
  `  Node* cur = head;`,
  `  while (cur->next) cur = cur->next; // traverse to end`,
  `  cur->next = n;                     // link new node`,
  `}`,
  ``,
  `bool deleteNode(int val) {`,
  `  Node *cur=head, *prev=nullptr;`,
  `  while (cur && cur->data!=val) {    // find node`,
  `    prev=cur; cur=cur->next;`,
  `  }`,
  `  if (!cur) return false;            // not found`,
  `  if (!prev) head = cur->next;       // remove head`,
  `  else prev->next = cur->next;       // unlink`,
  `  delete cur; return true;`,
  `}`,
  ``,
  `bool search(int val) {`,
  `  Node* cur = head;`,
  `  while (cur) {                      // linear scan`,
  `    if (cur->data == val) return true;`,
  `    cur = cur->next;`,
  `  }`,
  `  return false;`,
  `}`,
];

const ACTION_LINE = {
  insertBack:  5,
  insertFront: 5,
  searching:   24,
  found:       25,
  notFound:    28,
  delete:      18,
  traverse:    24,
  traverseEnd: 29,
};

// ll_state is an array of node values
let ll_state = [];

function renderLL(state, highlightIdx = -1, foundIdx = -1) {
  const vis = document.getElementById('ll-vis');
  vis.innerHTML = '';
  if (state.length === 0) {
    vis.innerHTML = '<span style="color:var(--text-dim);font-size:.85rem;">List is empty — HEAD → NULL</span>';
    return;
  }
  state.forEach((val, i) => {
    const nodeWrap = document.createElement('div');
    nodeWrap.className = 'll-node';

    const box = document.createElement('div');
    box.className = 'll-box' +
      (i === highlightIdx ? ' highlight' : '') +
      (i === foundIdx ? ' found' : '');

    const dataEl = document.createElement('div');
    dataEl.className = 'll-data';
    dataEl.textContent = val;

    const nextEl = document.createElement('div');
    nextEl.className = 'll-next';
    nextEl.textContent = i < state.length - 1 ? 'next' : 'null';

    box.appendChild(dataEl);
    box.appendChild(nextEl);
    nodeWrap.appendChild(box);

    if (i < state.length - 1) {
      const arrow = document.createElement('span');
      arrow.className = 'll-arrow';
      arrow.textContent = '→';
      nodeWrap.appendChild(arrow);
    } else {
      const nullLabel = document.createElement('span');
      nullLabel.className = 'll-null';
      nullLabel.textContent = '→ NULL';
      nodeWrap.appendChild(nullLabel);
    }

    vis.appendChild(nodeWrap);
  });
}

async function applyStep(step) {
  const line = ACTION_LINE[step.action] || -1;
  renderCode('code-view', LL_CODE, line);

  const typeMap = {
    insertBack:'success', insertFront:'success',
    delete:'warn', searching:'info', found:'success',
    notFound:'error', traverse:'info', traverseEnd:'success'
  };
  setMsg(step.message, typeMap[step.action] || '');

  const hlIdx    = (step.highlight !== undefined) ? step.highlight : -1;
  const foundIdx = (step.action === 'found') ? step.highlight : -1;
  renderLL(step.state || ll_state, hlIdx, foundIdx);
  if (step.state) ll_state = [...step.state];
  await new Promise(r => setTimeout(r, 50));
}

async function runCommand(cmd) {
  const res = await DSV.run('linkedlist', cmd);
  if (res.error) { setMsg('Error: ' + res.error, 'error'); return; }
  for (const step of res.steps) {
    await applyStep(step);
    await new Promise(r => setTimeout(r, step.action === 'searching' ? 600 : 350));
  }
}

function buildStateCmd() {
  return ll_state.map(x => `insert ${x}`).join('\n');
}

async function doInsertBack() {
  const v = document.getElementById('val-input').value.trim();
  if (!v) { setMsg('Enter a value first.', 'warn'); return; }
  document.getElementById('op-select').value = 'insertBack'; updateComplexity();
  await runCommand(buildStateCmd() + `\ninsert ${v}`);
}

async function doInsertFront() {
  const v = document.getElementById('val-input').value.trim();
  if (!v) { setMsg('Enter a value first.', 'warn'); return; }
  document.getElementById('op-select').value = 'insertFront'; updateComplexity();
  await runCommand(buildStateCmd() + `\ninsertFront ${v}`);
}

async function doDelete() {
  const v = document.getElementById('val-input').value.trim();
  if (!v) { setMsg('Enter a value to delete.', 'warn'); return; }
  document.getElementById('op-select').value = 'delete'; updateComplexity();
  await runCommand(buildStateCmd() + `\ndelete ${v}`);
}

async function doSearch() {
  const v = document.getElementById('val-input').value.trim();
  if (!v) { setMsg('Enter a value to search.', 'warn'); return; }
  document.getElementById('op-select').value = 'search'; updateComplexity();
  await runCommand(buildStateCmd() + `\nsearch ${v}`);
}

async function doTraverse() {
  if (ll_state.length === 0) { setMsg('List is empty!', 'error'); return; }
  await runCommand(buildStateCmd() + '\ntraverse');
}

function doReset() {
  ll_state = [];
  renderLL([]);
  setMsg('List cleared.', 'info');
  renderCode('code-view', LL_CODE);
}

function updateComplexity() {
  const op = document.getElementById('op-select').value;
  renderComplexity('linkedlist', op);
}

renderCode('code-view', LL_CODE);
renderComplexity('linkedlist', 'search');
renderLL([]);
