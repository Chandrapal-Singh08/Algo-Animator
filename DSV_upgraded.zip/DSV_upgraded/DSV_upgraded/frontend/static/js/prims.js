/**
 * Prim's MST Visualizer JS
 */

const PRIMS_CODE = [
  `void primMST() {`,
  `  key.assign(n, INT_MAX);`,
  `  inMST.assign(n, false);`,
  `  key[0] = 0; parent[0] = -1;     // start from 0`,
  `  for (int count = 0; count < n; count++) {`,
  `    int u = minKey();               // pick min key`,
  `    inMST[u] = true;               // add to MST`,
  `    for (int v = 0; v < n; v++) {`,
  `      if (graph[u][v] && !inMST[v]`,
  `          && graph[u][v] < key[v]) {`,
  `        key[v] = graph[u][v];      // update key`,
  `        parent[v] = u;             // update parent`,
  `      }`,
  `    }`,
  `  }`,
  `}`,
];

const PRIMS_LINE = { init:4, addVertex:7, checkEdge:9, updateKey:11, done:16 };

let primsMatrix = null, primsN = 0;
let primsPlayer = null;
let primsInMST = new Set(), primsMSTEdges = [];

function parsePrimsInput() {
  const raw = document.getElementById('matrix-input').value.trim();
  const nums = raw.split(/\s+/).map(Number);
  const n = nums[0];
  const mat = [];
  for (let i = 0; i < n; i++) mat.push(nums.slice(1 + i*n, 1 + (i+1)*n));
  return { n, mat };
}

function onPrimsStep(step, idx, total) {
  renderCode('code-view', PRIMS_CODE, PRIMS_LINE[step.action] || -1);
  setMsg(step.message || '', step.action==='done' ? 'success' : 'info');
  updateStepCounter(primsPlayer);

  if (step.inMST) primsInMST = new Set(step.inMST.map((v,i)=>v?i:-1).filter(i=>i>=0));

  // Build MST edges from parent array
  if (step.parent) {
    primsMSTEdges = [];
    step.parent.forEach((p,i) => { if (p >= 0) primsMSTEdges.push({u:p, v:i}); });
  }

  const activeEdge = (step.u >= 0 && step.v >= 0) ? { u:step.u, v:step.v } : null;

  drawGraph('graph-svg', primsN, primsMatrix, {
    visitedNodes: primsInMST,
    activeEdge,
    mstEdges: primsMSTEdges,
    highlightNode: step.u >= 0 ? step.u : -1,
  });
  updatePlayBtn(primsPlayer, 'btn-play');
}

async function doRun() {
  try {
    const { n, mat } = parsePrimsInput();
    primsN = n; primsMatrix = mat;

    let inp = `${n}\n`;
    mat.forEach(row => inp += row.join(' ') + '\n');

    setMsg('Running Prim\'s MST…', 'info');
    const res = await DSV.run('prims', inp);
    if (res.error) { setMsg('Error: ' + res.error, 'error'); return; }

    primsInMST = new Set(); primsMSTEdges = [];

    primsPlayer = new StepPlayer({
      steps: res.steps,
      onStep: onPrimsStep,
      onDone: () => setMsg('✅ Prim\'s MST complete!', 'success'),
      getSpeed: () => 1100 - parseInt(document.getElementById('speed-range').value),
    });

    ['btn-play','btn-prev','btn-next'].forEach(id => {
      const b = document.getElementById(id); if (b) b.disabled = false;
    });

    drawGraph('graph-svg', primsN, primsMatrix, {});
    primsPlayer.reset();

  } catch(e) { setMsg('Parse error — check matrix format.', 'error'); }
}

function togglePlay() { primsPlayer && primsPlayer.toggle(); updatePlayBtn(primsPlayer,'btn-play'); }
function stepNext()   { primsPlayer && (primsPlayer.pause(), primsPlayer.next()); updatePlayBtn(primsPlayer,'btn-play'); }
function stepPrev()   { primsPlayer && (primsPlayer.pause(), primsPlayer.prev()); updatePlayBtn(primsPlayer,'btn-play'); }

function loadExample() {
  document.getElementById('matrix-input').value =
`5
0 2 0 6 0
2 0 3 8 5
0 3 0 0 7
6 8 0 0 9
0 5 7 9 0`;
}

renderCode('code-view', PRIMS_CODE);
renderComplexity('prims', 'prims');
loadExample();
