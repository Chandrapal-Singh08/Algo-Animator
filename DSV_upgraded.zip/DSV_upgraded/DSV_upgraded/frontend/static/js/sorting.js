/**
 * Sorting Visualizer JS
 * StepPlayer-based with bar chart, code tracing, speed control
 */

// ── Code per algorithm ────────────────────────────────────────────────────────
const SORT_CODE = {
  bubble: [
    `void bubbleSort(vector<int>& arr) {`,
    `  int n = arr.size();`,
    `  for (int i = 0; i < n-1; i++) {`,
    `    bool swapped = false;`,
    `    for (int j = 0; j < n-i-1; j++) {`,
    `      if (arr[j] > arr[j+1]) {       // compare`,
    `        swap(arr[j], arr[j+1]);       // swap`,
    `        swapped = true;`,
    `      }`,
    `    } // end inner loop`,
    `    if (!swapped) break;             // already sorted`,
    `  }`,
    `}`,
  ],
  insertion: [
    `void insertionSort(vector<int>& arr) {`,
    `  int n = arr.size();`,
    `  for (int i = 1; i < n; i++) {`,
    `    int key = arr[i];               // pick current`,
    `    int j = i - 1;`,
    `    while (j >= 0 && arr[j] > key) {`,
    `      arr[j+1] = arr[j];            // shift right`,
    `      j--;`,
    `    }`,
    `    arr[j+1] = key;                 // insert key`,
    `  }`,
    `}`,
  ],
  selection: [
    `void selectionSort(vector<int>& arr) {`,
    `  int n = arr.size();`,
    `  for (int i = 0; i < n-1; i++) {`,
    `    int minIdx = i;                 // assume min`,
    `    for (int j = i+1; j < n; j++) {`,
    `      if (arr[j] < arr[minIdx])     // found smaller`,
    `        minIdx = j;`,
    `    }`,
    `    swap(arr[i], arr[minIdx]);      // place minimum`,
    `  }`,
    `}`,
  ],
  merge: [
    `void mergeSort(vector<int>& arr, int l, int r) {`,
    `  if (l >= r) return;`,
    `  int m = l + (r-l)/2;`,
    `  mergeSort(arr, l, m);            // sort left half`,
    `  mergeSort(arr, m+1, r);          // sort right half`,
    `  merge(arr, l, m, r);             // merge halves`,
    `}`,
    `void merge(vector<int>& arr, int l, int m, int r) {`,
    `  vector<int> left(arr.begin()+l, arr.begin()+m+1);`,
    `  vector<int> right(arr.begin()+m+1, arr.begin()+r+1);`,
    `  int i=0, j=0, k=l;`,
    `  while (i<left.size() && j<right.size())`,
    `    arr[k++] = (left[i]<=right[j]) ? left[i++] : right[j++];`,
    `}`,
  ],
  quick: [
    `void quickSort(vector<int>& arr, int low, int high) {`,
    `  if (low < high) {`,
    `    int pi = partition(arr, low, high);`,
    `    quickSort(arr, low, pi-1);     // sort left`,
    `    quickSort(arr, pi+1, high);    // sort right`,
    `  }`,
    `}`,
    `int partition(vector<int>& arr, int low, int high) {`,
    `  int pivot = arr[high];           // last as pivot`,
    `  int i = low - 1;`,
    `  for (int j = low; j < high; j++) {`,
    `    if (arr[j] <= pivot) {         // compare`,
    `      swap(arr[++i], arr[j]);      // swap smaller`,
    `    }`,
    `  }`,
    `  swap(arr[i+1], arr[high]);       // place pivot`,
    `  return i+1;`,
    `}`,
  ],
};

// ── State ─────────────────────────────────────────────────────────────────────
let player = null;
let allSteps = [];
let maxVal = 1;

// ── Bar chart renderer ────────────────────────────────────────────────────────
function renderBars(state) {
  const vis = document.getElementById('sort-vis');
  vis.innerHTML = '';
  if (!state || !state.arr) return;

  const arr = state.arr;
  maxVal = Math.max(...arr, 1);
  const containerH = 260;

  arr.forEach((v, i) => {
    const barH = Math.max(18, Math.round((v / maxVal) * containerH));
    const bar = document.createElement('div');
    bar.className = 'sort-bar';
    bar.style.height = barH + 'px';
    bar.dataset.idx = i;

    // Colour logic
    if (state.pivot !== undefined && i === state.pivot) bar.classList.add('pivot');
    else if (i === state.cmp1 || i === state.cmp2)       bar.classList.add('comparing');
    else if (state.sortedUpto !== undefined && i <= state.sortedUpto) bar.classList.add('sorted');

    const label = document.createElement('span');
    label.className = 'bar-val';
    label.textContent = v;
    bar.appendChild(label);

    vis.appendChild(bar);
  });

  // Legend
  const legend = document.getElementById('sort-legend');
  legend.innerHTML = `
    <span style="display:flex;align-items:center;gap:5px;">
      <span style="width:12px;height:12px;border-radius:2px;background:var(--yellow);display:inline-block"></span>Comparing
    </span>
    <span style="display:flex;align-items:center;gap:5px;">
      <span style="width:12px;height:12px;border-radius:2px;background:var(--red);display:inline-block"></span>Swapping
    </span>
    <span style="display:flex;align-items:center;gap:5px;">
      <span style="width:12px;height:12px;border-radius:2px;background:var(--green);display:inline-block"></span>Sorted
    </span>
    <span style="display:flex;align-items:center;gap:5px;">
      <span style="width:12px;height:12px;border-radius:2px;background:var(--accent2);display:inline-block"></span>Pivot
    </span>`;
}

// ── Step callback ─────────────────────────────────────────────────────────────
function onStep(step, idx, total) {
  const algo = document.getElementById('algo-select').value;
  const code = SORT_CODE[algo] || [];
  renderCode('code-view', code, step.line || -1);
  setMsg(step.message || '', '');
  if (step.state) renderBars(step.state);
  updateStepCounter(player);

  const pBtn = document.getElementById('btn-play');
  if (pBtn) pBtn.textContent = player.isPlaying() ? '⏸ Pause' : '▶ Play';
}

function onDone() {
  setMsg('✅ Sort complete!', 'success');
  const pBtn = document.getElementById('btn-play');
  if (pBtn) pBtn.textContent = '▶ Play';
}

// ── Controls ──────────────────────────────────────────────────────────────────
function getSpeed() {
  const r = document.getElementById('speed-range');
  // Invert: higher slider = faster = lower ms
  return 1050 - parseInt(r ? r.value : 400);
}

function togglePlay() {
  if (!player) return;
  player.toggle();
  updatePlayBtn(player, 'btn-play');
}

function stepNext() {
  if (!player) return;
  player.pause();
  player.next();
  updatePlayBtn(player, 'btn-play');
}

function stepPrev() {
  if (!player) return;
  player.pause();
  player.prev();
  updatePlayBtn(player, 'btn-play');
}

function restartPlay() {
  if (!player) return;
  player.pause();
  player.idx = -1;
  player.reset();
  updatePlayBtn(player, 'btn-play');
}

function setButtonsEnabled(en) {
  ['btn-play','btn-prev','btn-next','btn-restart'].forEach(id => {
    const b = document.getElementById(id);
    if (b) b.disabled = !en;
  });
}

// ── Sort trigger ──────────────────────────────────────────────────────────────
async function doSort() {
  const algo  = document.getElementById('algo-select').value;
  const input = document.getElementById('arr-input').value.trim();
  if (!input) { setMsg('Enter an array first.', 'warn'); return; }

  const nums = input.split(/\s+/).filter(Boolean);
  if (nums.length < 2) { setMsg('Need at least 2 numbers.', 'warn'); return; }
  if (nums.length > 30) { setMsg('Max 30 elements for clear visualization.', 'warn'); return; }

  setMsg('Running…', 'info');
  setButtonsEnabled(false);

  const inputStr = `${algo} ${nums.length} ${nums.join(' ')}`;
  const res = await DSV.run('sorting', inputStr);
  if (res.error) { setMsg('Error: ' + res.error, 'error'); return; }

  allSteps = res.steps;
  player = new StepPlayer({
    steps: allSteps,
    onStep,
    onDone,
    getSpeed,
  });

  setButtonsEnabled(true);
  player.reset();
  updateStepCounter(player);
}

function doRandom() {
  const n = Math.floor(Math.random() * 8) + 5;
  const arr = Array.from({ length: n }, () => Math.floor(Math.random() * 90) + 10);
  document.getElementById('arr-input').value = arr.join(' ');
}

function doReset() {
  player = null;
  allSteps = [];
  document.getElementById('sort-vis').innerHTML = '';
  document.getElementById('sort-legend').innerHTML = '';
  setMsg('Reset. Enter a new array.', 'info');
  setButtonsEnabled(false);
  const sc = document.getElementById('step-counter');
  if (sc) sc.textContent = 'Step 0 / 0';
  const algo = document.getElementById('algo-select').value;
  renderCode('code-view', SORT_CODE[algo] || []);
}

function updateComplexity() {
  renderComplexity('sorting', document.getElementById('algo-select').value);
  const algo = document.getElementById('algo-select').value;
  renderCode('code-view', SORT_CODE[algo] || []);
}

// Speed label live update
document.addEventListener('DOMContentLoaded', () => {
  const range = document.getElementById('speed-range');
  const label = document.getElementById('speed-label');
  if (range && label) {
    range.addEventListener('input', () => { label.textContent = range.value + 'ms'; });
  }
});

// ── Init ──────────────────────────────────────────────────────────────────────
renderComplexity('sorting', 'bubble');
renderCode('code-view', SORT_CODE['bubble']);
doRandom();
