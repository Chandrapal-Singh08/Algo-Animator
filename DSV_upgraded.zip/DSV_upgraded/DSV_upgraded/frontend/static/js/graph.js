/**
 * Shared Graph Drawing Utilities (SVG)
 * Used by Dijkstra, Prim's, Kruskal pages
 */

const GSVG_NS = 'http://www.w3.org/2000/svg';

/**
 * Lay out n nodes in a circle inside the SVG.
 * Returns array of {x, y} positions.
 */
function circleLayout(n, svgEl) {
  const W = svgEl.clientWidth  || 400;
  const H = svgEl.clientHeight || 300;
  const cx = W / 2, cy = H / 2;
  const r  = Math.min(W, H) * 0.38;
  return Array.from({ length: n }, (_, i) => {
    const angle = (2 * Math.PI * i / n) - Math.PI / 2;
    return { x: cx + r * Math.cos(angle), y: cy + r * Math.sin(angle) };
  });
}

/**
 * Draw a weighted undirected graph.
 * @param {string}   svgId        SVG element id
 * @param {number}   n            Number of vertices
 * @param {number[][]} matrix     Adjacency matrix (0 = no edge)
 * @param {object}   opts
 *   visitedNodes  : Set of visited node indices (green)
 *   activeEdge    : {u, v}  currently relaxing (yellow)
 *   mstEdges      : [{u,v}] edges in MST/SP tree (blue)
 *   distLabels    : string[]  per-node label override
 *   highlightNode : index to highlight orange
 */
function drawGraph(svgId, n, matrix, opts = {}) {
  const svg = document.getElementById(svgId);
  if (!svg) return;
  svg.innerHTML = '';

  // Make sure SVG has proper size
  const W = svg.parentElement ? svg.parentElement.clientWidth * 0.55 : 400;
  const H = 320;
  svg.setAttribute('width',  Math.max(W, 300));
  svg.setAttribute('height', H);
  svg.setAttribute('viewBox', `0 0 ${Math.max(W,300)} ${H}`);

  const pos = circleLayout(n, svg);
  const { visitedNodes = new Set(), activeEdge = null,
          mstEdges = [], highlightNode = -1, distLabels = [] } = opts;

  const mstSet = new Set(mstEdges.map(e => `${Math.min(e.u,e.v)}-${Math.max(e.u,e.v)}`));

  // ── Draw edges ────────────────────────────────────────────────────────────
  for (let u = 0; u < n; u++) {
    for (let v = u + 1; v < n; v++) {
      if (!matrix[u][v]) continue;
      const key = `${u}-${v}`;
      const isActive = activeEdge && ((activeEdge.u===u&&activeEdge.v===v)||(activeEdge.u===v&&activeEdge.v===u));
      const isMST    = mstSet.has(key);

      const line = document.createElementNS(GSVG_NS, 'line');
      line.setAttribute('x1', pos[u].x); line.setAttribute('y1', pos[u].y);
      line.setAttribute('x2', pos[v].x); line.setAttribute('y2', pos[v].y);
      line.setAttribute('stroke-width', isMST ? '3' : '1.5');
      line.setAttribute('stroke', isActive ? '#f59e0b' : isMST ? '#3b82f6' : '#374151');
      if (isActive) line.setAttribute('filter', 'drop-shadow(0 0 5px #f59e0b)');
      svg.appendChild(line);

      // Weight label at midpoint
      const mx = (pos[u].x + pos[v].x) / 2;
      const my = (pos[u].y + pos[v].y) / 2;
      const wt = document.createElementNS(GSVG_NS, 'text');
      wt.setAttribute('x', mx); wt.setAttribute('y', my - 5);
      wt.setAttribute('text-anchor', 'middle');
      wt.setAttribute('fill', isActive ? '#f59e0b' : '#6b7280');
      wt.setAttribute('font-size', '11');
      wt.setAttribute('font-family', 'Inter, sans-serif');
      wt.textContent = matrix[u][v];
      svg.appendChild(wt);
    }
  }

  // ── Draw nodes ────────────────────────────────────────────────────────────
  for (let i = 0; i < n; i++) {
    const { x, y } = pos[i];
    const isVisited  = visitedNodes.has(i);
    const isHL       = i === highlightNode;

    const circle = document.createElementNS(GSVG_NS, 'circle');
    circle.setAttribute('cx', x); circle.setAttribute('cy', y); circle.setAttribute('r', 20);
    circle.setAttribute('fill',   isHL ? '#f59e0b' : isVisited ? '#065f46' : '#1e293b');
    circle.setAttribute('stroke', isHL ? '#fbbf24' : isVisited ? '#10b981'  : '#4b5563');
    circle.setAttribute('stroke-width', '2');
    if (isHL || isVisited) circle.setAttribute('filter',
      `drop-shadow(0 0 6px ${isHL ? '#f59e0b' : '#10b981'})`);
    svg.appendChild(circle);

    // Node label
    const label = document.createElementNS(GSVG_NS, 'text');
    label.setAttribute('x', x); label.setAttribute('y', y + 5);
    label.setAttribute('text-anchor', 'middle');
    label.setAttribute('fill', 'white');
    label.setAttribute('font-size', '13');
    label.setAttribute('font-weight', 'bold');
    label.setAttribute('font-family', 'Inter, sans-serif');
    label.textContent = i;
    svg.appendChild(label);

    // Distance / key label below node
    if (distLabels[i] !== undefined) {
      const dl = document.createElementNS(GSVG_NS, 'text');
      dl.setAttribute('x', x); dl.setAttribute('y', y + 36);
      dl.setAttribute('text-anchor', 'middle');
      dl.setAttribute('fill', '#94a3b8');
      dl.setAttribute('font-size', '10');
      dl.setAttribute('font-family', 'monospace');
      dl.textContent = distLabels[i];
      svg.appendChild(dl);
    }
  }
}

/**
 * Render a distance table for Dijkstra
 */
function renderDistTable(containerId, dist, n) {
  const el = document.getElementById(containerId);
  if (!el) return;
  const INF = 999999;
  let html = `<table class="complexity-table">
    <thead><tr><th>Vertex</th><th>Distance</th></tr></thead><tbody>`;
  for (let i = 0; i < n; i++) {
    const d = dist[i];
    const col = d === INF ? 'var(--red)' : d === 0 ? 'var(--green)' : 'var(--yellow)';
    html += `<tr><td>v${i}</td><td style="color:${col};font-weight:600">${d === INF ? '∞' : d}</td></tr>`;
  }
  html += '</tbody></table>';
  el.innerHTML = html;
}
