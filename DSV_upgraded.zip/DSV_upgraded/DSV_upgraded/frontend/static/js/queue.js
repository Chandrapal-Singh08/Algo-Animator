/**
 * Queue Visualizer JS
 */

const QUEUE_CODE = [
  `// Queue — C++ OOP Implementation`,
  `class Queue {`,
  `  deque<int> data;`,
  `public:`,
  `  bool enqueue(int val) {`,
  `    if (data.size() >= MAX) return false;`,
  `    data.push_back(val);   // add to rear`,
  `    return true;`,
  `  }`,
  `  bool dequeue() {`,
  `    if (data.empty()) return false;`,
  `    data.pop_front();      // remove from front`,
  `    return true;`,
  `  }`,
  `  int front() const {`,
  `    return data.front();   // peek front`,
  `  }`,
  `  bool isEmpty() const { return data.empty(); }`,
  `};`,
];

const ACTION_LINE = {
  enqueue:   5,
  overflow:  6,
  dequeue:   11,
  underflow: 12,
  front:     16,
  empty:     17,
};

let queueState = [];

function renderQueue(state, highlightFront = false, highlightRear = false) {
  const vis = document.getElementById('queue-vis');
  vis.innerHTML = '';
  if (state.length === 0) {
    vis.innerHTML = '<span style="color:var(--text-dim);font-size:.85rem;">Queue is empty</span>';
    return;
  }
  state.forEach((val, i) => {
    const item = document.createElement('div');
    item.className = 'queue-item';
    if (i === 0 && highlightFront) item.style.borderColor = 'var(--yellow)';
    if (i === state.length - 1 && highlightRear) item.style.borderColor = 'var(--accent)';
    item.textContent = val;
    vis.appendChild(item);

    if (i < state.length - 1) {
      const arr = document.createElement('span');
      arr.className = 'queue-arrow';
      arr.textContent = '→';
      vis.appendChild(arr);
    }
  });
}

async function applyStep(step) {
  const line = ACTION_LINE[step.action] || -1;
  renderCode('code-view', QUEUE_CODE, line);
  const typeMap = { enqueue:'success', dequeue:'warn', front:'info', overflow:'error', underflow:'error' };
  setMsg(step.message, typeMap[step.action] || '');
  const hlFront = step.action === 'dequeue' || step.action === 'front';
  const hlRear  = step.action === 'enqueue';
  renderQueue(step.state || queueState, hlFront, hlRear);
  if (step.state) queueState = [...step.state];
  await new Promise(r => setTimeout(r, 50));
}

async function runCommand(cmd) {
  const res = await DSV.run('queue', cmd);
  if (res.error) { setMsg('Error: ' + res.error, 'error'); return; }
  for (const step of res.steps) {
    await applyStep(step);
    await new Promise(r => setTimeout(r, 350));
  }
}

async function doEnqueue() {
  const v = document.getElementById('val-input').value.trim();
  if (!v) { setMsg('Enter a value first.', 'warn'); return; }
  document.getElementById('op-select').value = 'enqueue';
  updateComplexity();
  const cmds = queueState.map(x => `enqueue ${x}`).join('\n') + `\nenqueue ${v}`;
  await runCommand(cmds);
}

async function doDequeue() {
  if (queueState.length === 0) { setMsg('Queue is empty!', 'error'); return; }
  document.getElementById('op-select').value = 'dequeue';
  updateComplexity();
  const cmds = queueState.map(x => `enqueue ${x}`).join('\n') + '\ndequeue';
  await runCommand(cmds);
}

async function doFront() {
  if (queueState.length === 0) { setMsg('Queue is empty!', 'error'); return; }
  const cmds = queueState.map(x => `enqueue ${x}`).join('\n') + '\nfront';
  await runCommand(cmds);
}

function doReset() {
  queueState = [];
  renderQueue([]);
  setMsg('Queue cleared.', 'info');
  renderCode('code-view', QUEUE_CODE);
}

function updateComplexity() {
  const op = document.getElementById('op-select').value;
  renderComplexity('queue', op);
}

renderCode('code-view', QUEUE_CODE);
renderComplexity('queue', 'enqueue');
renderQueue([]);
