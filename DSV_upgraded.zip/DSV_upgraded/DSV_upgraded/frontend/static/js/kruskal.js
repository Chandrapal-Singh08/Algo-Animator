/**
 * Kruskal's MST Visualizer JS
 */

const KRUSKAL_CODE = [
  `void kruskal() {`,
  `  sort(edges.begin(), edges.end()); // sort by weight`,
  `  UnionFind uf(n);`,
  `  for (auto& e : edges) {`,
  `    if (uf.find(e.u) != uf.find(e.v)) { // no cycle?`,
  `      mst.push_back(e);              // add edge`,
  `      uf.unite(e.u, e.v);            // union sets`,
  `      cost += e.w;`,
  `      if (mst.size() == n-1) break;  // MST complete`,
  `    } else {`,
  `      // skip — would form a cycle`,
  `    }`,
  `  }`,
  `}`,
  `// Union-Find with path compression + rank`,
  `int find(int x) {`,
  `  if (parent[x] != x) parent[x] = find(parent[x]);`,
  `  return parent[x];`,
  `}`,
];

const KRUSKAL_LINE = {
  init: 2, consider: 4, addEdge: 6, skipEdge: 11, done: 14
};

let kruskalN = 0, kruskalMatrix = null, allEdges = [];
let kruskalPlayer = null, kruskalMSTEdges = [];

function parseKruskalInput() {
  const raw = document.getElementById('edges-input').value.trim();
  const lines = raw.split('\n').map(l => l.trim()).filter(Boolean);
  const [n, e] = lines[0].split(/\s+/).map(Number);
  const edges = [];
  const mat = Array.from({ length: n }, () => Array(n).fill(0));
  for (let i = 1; i <= e; i++) {
    const [u, v, w] = lines[i].split(/\s+/).map(Number);
    edges.push({ u, v, w });
    mat[u][v] = w; mat[v][u] = w;
  }
  return { n, e, edges, mat };
}

function renderEdgeTable(edges, mstSet) {
  const el = document.getElementById('edge-table-wrap');
  if (!el) return;
  let html = `<table class="complexity-table">
    <thead><tr><th>u</th><th>v</th><th>w</th><th>In MST?</th></tr></thead><tbody>`;
  edges.forEach(e => {
    const key = `${Math.min(e.u,e.v)}-${Math.max(e.u,e.v)}`;
    const inMST = mstSet.has(key);
    html += `<tr style="${inMST ? 'color:var(--green)' : ''}">
      <td>${e.u}</td><td>${e.v}</td><td>${e.w}</td>
      <td>${inMST ? '✅' : '—'}</td></tr>`;
  });
  html += '</tbody></table>';
  el.innerHTML = html;
}

function onKruskalStep(step, idx, total) {
  renderCode('code-view', KRUSKAL_CODE, KRUSKAL_LINE[step.action] || -1);
  const typeMap = { addEdge:'success', skipEdge:'warn', done:'success', consider:'info' };
  setMsg(step.message || '', typeMap[step.action] || 'info');
  updateStepCounter(kruskalPlayer);

  if (step.mstEdges) kruskalMSTEdges = step.mstEdges;

  const mstSet = new Set(kruskalMSTEdges.map(e => `${Math.min(e.u,e.v)}-${Math.max(e.u,e.v)}`));

  const activeEdge = (step.u !== undefined && step.v !== undefined && step.action !== 'done')
    ? { u: step.u, v: step.v } : null;

  drawGraph('graph-svg', kruskalN, kruskalMatrix, {
    mstEdges: kruskalMSTEdges,
    activeEdge,
  });
  renderEdgeTable(allEdges, mstSet);
  updatePlayBtn(kruskalPlayer, 'btn-play');
}

async function doRun() {
  try {
    const { n, e, edges, mat } = parseKruskalInput();
    kruskalN = n; kruskalMatrix = mat; allEdges = edges; kruskalMSTEdges = [];

    let inp = `${n} ${e}\n`;
    edges.forEach(({ u, v, w }) => inp += `${u} ${v} ${w}\n`);

    setMsg('Running Kruskal\'s MST…', 'info');
    const res = await DSV.run('kruskal', inp);
    if (res.error) { setMsg('Error: ' + res.error, 'error'); return; }

    kruskalPlayer = new StepPlayer({
      steps: res.steps,
      onStep: onKruskalStep,
      onDone: () => setMsg('✅ Kruskal\'s MST complete!', 'success'),
      getSpeed: () => 1100 - parseInt(document.getElementById('speed-range').value),
    });

    ['btn-play','btn-prev','btn-next'].forEach(id => {
      const b = document.getElementById(id); if (b) b.disabled = false;
    });

    drawGraph('graph-svg', kruskalN, kruskalMatrix, {});
    renderEdgeTable(allEdges, new Set());
    kruskalPlayer.reset();

  } catch(e) { console.error(e); setMsg('Parse error — check edge list format.', 'error'); }
}

function togglePlay() { kruskalPlayer && kruskalPlayer.toggle(); updatePlayBtn(kruskalPlayer,'btn-play'); }
function stepNext()   { kruskalPlayer && (kruskalPlayer.pause(), kruskalPlayer.next()); updatePlayBtn(kruskalPlayer,'btn-play'); }
function stepPrev()   { kruskalPlayer && (kruskalPlayer.pause(), kruskalPlayer.prev()); updatePlayBtn(kruskalPlayer,'btn-play'); }

function loadExample() {
  document.getElementById('edges-input').value =
`6 9
0 1 4
0 2 4
1 2 2
1 3 5
2 4 6
3 4 5
3 5 3
4 5 7
2 3 8`;
}

renderCode('code-view', KRUSKAL_CODE);
renderComplexity('kruskal', 'kruskal');
loadExample();
