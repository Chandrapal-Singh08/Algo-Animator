"""
DSV - Data Structures Visualizer Backend
Flask application serving all algorithm endpoints
"""

import os
import json
import subprocess
import tempfile
from pathlib import Path
from flask import Flask, render_template, request, jsonify

app = Flask(__name__, template_folder='../frontend/templates',
            static_folder='../frontend/static')

# ── Paths ──────────────────────────────────────────────────────────────────────
BASE_DIR = Path(__file__).parent.parent
ALGO_DIR = BASE_DIR / "algorithms"

BINARY_MAP = {
    "stack":       ALGO_DIR / "Stack"   / "stack_exec.exe",
    "queue":       ALGO_DIR / "Queue"   / "queue_exec.exe",
    "linkedlist":  ALGO_DIR / "LinkedList" / "linkedlist_exec.exe",
    "tree":        ALGO_DIR / "Tree"    / "tree_exec.exe",
    "dijkstra":    ALGO_DIR / "Graph"   / "Dijkstra" / "dijkstra_exec.exe",
    "prims":       ALGO_DIR / "Graph"   / "Prims"    / "prims_exec.exe",
    "kruskal":     ALGO_DIR / "Graph"   / "Kruskal"  / "kruskal_exec.exe",
    "sorting":     ALGO_DIR / "Sorting" / "sorting_exec.exe",
}


def run_algorithm(name: str, input_data: str) -> dict:
    """Run a compiled C++ binary with the given input and return parsed JSON steps."""
    binary = BINARY_MAP.get(name)
    if not binary or not binary.exists():
        return {"error": f"Binary not found for '{name}'. Compile first.", "steps": []}

    # Use temp files to avoid race conditions
    with tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False) as fin:
        fin.write(input_data.strip())
        input_path = fin.name

    output_path = input_path.replace('.txt', '_out.txt')

    try:
        result = subprocess.run(
            [str(binary), input_path, output_path],
            capture_output=True, text=True, timeout=10
        )
        if result.returncode != 0:
            return {"error": result.stderr or "Algorithm failed", "steps": []}

        with open(output_path, 'r') as f:
            steps = json.load(f)
        return {"steps": steps}

    except subprocess.TimeoutExpired:
        return {"error": "Algorithm timed out (>10s)", "steps": []}
    except json.JSONDecodeError as e:
        return {"error": f"Invalid JSON output: {e}", "steps": []}
    finally:
        os.unlink(input_path)
        if os.path.exists(output_path):
            os.unlink(output_path)


# ── Pages ──────────────────────────────────────────────────────────────────────

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/stack')
def stack_page():   return render_template('stack.html')

@app.route('/queue')
def queue_page():   return render_template('queue.html')

@app.route('/linkedlist')
def ll_page():      return render_template('linkedlist.html')

@app.route('/tree')
def tree_page():    return render_template('tree.html')

@app.route('/dijkstra')
def dijkstra_page(): return render_template('dijkstra.html')

@app.route('/prims')
def prims_page():   return render_template('prims.html')

@app.route('/kruskal')
def kruskal_page(): return render_template('kruskal.html')

@app.route('/sorting')
def sorting_page(): return render_template('sorting.html')


# ── API Endpoints ──────────────────────────────────────────────────────────────

@app.route('/api/run', methods=['POST'])
def api_run():
    """
    Universal endpoint — accepts:
      { "algorithm": "<name>", "input": "<whitespace-separated commands>" }
    Returns:
      { "steps": [...] }  or  { "error": "..." }
    """
    data = request.get_json(silent=True)
    if not data:
        return jsonify({"error": "Invalid JSON body"}), 400

    algo  = data.get('algorithm', '').strip().lower()
    input_data = data.get('input', '').strip()

    if not algo:
        return jsonify({"error": "Missing 'algorithm' field"}), 400
    if algo not in BINARY_MAP:
        return jsonify({"error": f"Unknown algorithm '{algo}'"}), 400

    result = run_algorithm(algo, input_data)
    status = 500 if "error" in result else 200
    return jsonify(result), status


@app.route('/api/algorithms', methods=['GET'])
def api_list():
    """List all available algorithms and their binary status."""
    available = {}
    for name, path in BINARY_MAP.items():
        available[name] = {"compiled": path.exists()}
    return jsonify(available)


# ── Run ────────────────────────────────────────────────────────────────────────

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
