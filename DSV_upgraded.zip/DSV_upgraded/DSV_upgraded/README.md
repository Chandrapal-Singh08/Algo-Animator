# ⬡ DSV — Data Structures Visualizer

A modern, interactive web application for visualizing data structures and algorithms with **step-by-step animation**, **live C++ code tracing**, and **side-by-side complexity graphs**.

---

## ✨ Features

| Feature | Details |
|---|---|
| **C++ OOP Backends** | All algorithms rewritten in clean, modular C++17 |
| **Step-by-Step Playback** | Play / Pause / Next / Prev / Restart controls |
| **Live Code Tracing** | Highlighted C++ line tracks the current operation |
| **Complexity Graphs** | Time & Space charts side-by-side, update per operation |
| **Dark Professional UI** | CSS custom properties, responsive flex/grid layout |
| **Custom Input** | Enter your own arrays, trees, graphs |
| **Speed Control** | Slider adjusts animation delay (50ms – 1000ms) |

---

## 📁 Project Structure

```
DSV_upgraded/
├── Makefile                       ← Build all C++ binaries
├── requirements.txt               ← Python deps (Flask only)
│
├── algorithms/                    ← C++ source + compiled binaries
│   ├── Stack/         stack.cpp
│   ├── Queue/         queue.cpp
│   ├── LinkedList/    linkedlist.cpp
│   ├── Tree/          tree.cpp
│   ├── Sorting/       sorting.cpp
│   └── Graph/
│       ├── Dijkstra/  dijkstra.cpp
│       ├── Prims/     prims.cpp
│       └── Kruskal/   kruskal.cpp
│
├── backend/
│   └── app.py                     ← Flask server (single universal /api/run endpoint)
│
└── frontend/
    ├── templates/                 ← Jinja2 HTML pages
    │   ├── index.html
    │   ├── stack.html
    │   ├── queue.html
    │   ├── linkedlist.html
    │   ├── tree.html
    │   ├── sorting.html
    │   ├── dijkstra.html
    │   ├── prims.html
    │   └── kruskal.html
    └── static/
        ├── css/style.css          ← Global dark theme
        └── js/
            ├── dsv.js             ← Shared: API, StepPlayer, charts, code renderer
            ├── stack.js
            ├── queue.js
            ├── linkedlist.js
            ├── tree.js            ← SVG BST renderer
            ├── sorting.js         ← Bar chart + step player
            ├── graph.js           ← Shared SVG graph drawing
            ├── dijkstra.js
            ├── prims.js
            └── kruskal.js
```

---

## 🚀 Quick Start

### 1. Compile all C++ algorithms

```bash
make all
```

This compiles 8 binaries with `g++ -std=c++17 -O2`.

### 2. Install Python dependencies

```bash
pip install -r requirements.txt
```

### 3. Run the server

```bash
python backend/app.py
```

Visit **http://localhost:5000**

---

## 🏗 System Architecture

```
Browser ──POST /api/run──► Flask (app.py)
   ▲                            │
   │  JSON steps array          │ writes input.txt
   │                            ▼
   └──────────────── C++ binary (stack, tree, sorting…)
                                │
                          reads output.txt
                          (JSON array of steps)
```

### API Contract

**Request:**
```json
POST /api/run
{
  "algorithm": "stack",
  "input": "push 5\npush 3\npop"
}
```

**Response:**
```json
{
  "steps": [
    { "action": "push", "value": 5, "message": "Pushed 5 onto the stack", "state": [5] },
    { "action": "push", "value": 3, "message": "Pushed 3 onto the stack", "state": [5, 3] },
    { "action": "pop",  "value": 3, "message": "Popped 3 from the stack",  "state": [5] }
  ]
}
```

Each C++ binary reads `input.txt`, executes the algorithm while emitting a JSON step after every meaningful operation, and writes the complete `[…steps…]` array to `output.txt`. Flask reads that file and returns it to the browser.

---

## 📐 Algorithm Input Formats

### Stack
```
push <n>
pop
peek
```

### Queue
```
enqueue <n>
dequeue
front
```

### Linked List
```
insert <n>          ← insert at back
insertFront <n>     ← insert at front
delete <n>
search <n>
traverse
```

### Binary Search Tree
```
insert <n>
delete <n>
search <n>
inorder
```

### Dijkstra / Prim's (adjacency matrix)
```
<n>
<row 0 of n×n matrix>
<row 1 of n×n matrix>
...
<source node>       ← Dijkstra only
```

### Kruskal (edge list)
```
<n> <e>
<u> <v> <weight>
...              (e lines)
```

### Sorting
```
<algorithm> <n> <v1> <v2> ... <vn>
```
Algorithm must be one of: `bubble`, `insertion`, `selection`, `merge`, `quick`

---

## 🎨 UI Layout

Each page follows this 3-column responsive grid:

```
┌─────────────────────────────────────────────────────┐
│  Controls (full width)                              │
├────────────────────┬──────────────┬─────────────────┤
│                    │              │                 │
│   Visualization    │  Complexity  │   C++ Code      │
│   (SVG / bars /    │  (2 charts + │   (line-by-line │
│    boxes / nodes)  │   table)     │    highlighting) │
│                    │              │                 │
└────────────────────┴──────────────┴─────────────────┘
```

On tablet (`< 1100px`) the code panel drops below. On mobile (`< 720px`) everything stacks vertically.

---

## 🔧 Adding a New Algorithm

1. Create `algorithms/NewAlgo/newalgo.cpp`  
   — Output a JSON array of step objects to `argv[2]`

2. Add it to `BINARY_MAP` in `backend/app.py`

3. Create `frontend/templates/newalgo.html` (copy any existing template)

4. Create `frontend/static/js/newalgo.js`  
   — Define `CODE_LINES`, an `onStep()` callback, and call `renderComplexity()`

5. Add complexity data to the `COMPLEXITY` object in `dsv.js`

6. Add a nav link and a card on `index.html`

7. Run `make all` to compile

---

## 🧩 Key Components

### `StepPlayer` (dsv.js)
Encapsulates step-by-step playback. Constructor takes `{ steps, onStep, onDone, getSpeed }`.
Methods: `.play()`, `.pause()`, `.toggle()`, `.next()`, `.prev()`, `.reset()`

### `renderComplexity(ds, op)` (dsv.js)
Looks up complexity data for `ds` (e.g. `'stack'`) and operation `op` (e.g. `'push'`),
then draws both Time and Space Chart.js bar charts + fills the complexity table.

### `renderCode(containerId, lines, highlightLine)` (dsv.js)
Renders syntax-highlighted C++ code with the given line number glowing yellow.
Scrolls the highlighted line into view automatically.

### `drawGraph(svgId, n, matrix, opts)` (graph.js)
Draws a weighted undirected graph as an SVG circle layout.
Accepts `visitedNodes`, `activeEdge`, `mstEdges`, `highlightNode`, `distLabels`.

---

## 🗺 Complexity Reference

| Structure | Operation | Best | Avg | Worst | Space |
|---|---|---|---|---|---|
| Stack | push/pop/peek | O(1) | O(1) | O(1) | O(1) |
| Queue | enqueue/dequeue | O(1) | O(1) | O(1) | O(1) |
| Linked List | insert front | O(1) | O(1) | O(1) | O(1) |
| Linked List | insert back / search | O(n) | O(n) | O(n) | O(1) |
| BST | insert/search | O(log n) | O(log n) | O(n) | O(n) |
| Bubble Sort | — | O(n) | O(n²) | O(n²) | O(1) |
| Insertion Sort | — | O(n) | O(n²) | O(n²) | O(1) |
| Selection Sort | — | O(n²) | O(n²) | O(n²) | O(1) |
| Merge Sort | — | O(n log n) | O(n log n) | O(n log n) | O(n) |
| Quick Sort | — | O(n log n) | O(n log n) | O(n²) | O(log n) |
| Dijkstra | — | O(V²) | O(V²) | O(V²) | O(V) |
| Prim's | — | O(V²) | O(V²) | O(V²) | O(V+E) |
| Kruskal | — | O(E log E) | O(E log E) | O(E log E) | O(E+V) |

---

## 🧪 Running Tests

```bash
make test
```

---

## 📝 License

MIT — free for personal, academic, and portfolio use.
